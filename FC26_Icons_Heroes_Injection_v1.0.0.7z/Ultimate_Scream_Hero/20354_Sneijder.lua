-- Ultimate Scream Hero Wesley Sneijder (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 274750
-- Card UID : 20354
-- Fictive Player ID : 46011
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46011
local real_playerid = 274750
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "34",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "171",
    weight = "67",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "87",
    sprintspeed = "84",
    stamina = "82",
    agility = "85",
    balance = "85",
    jumping = "45",
    strength = "75",

    shortpassing = "90",
    longpassing = "94",
    vision = "94",
    curve = "88",

    ballcontrol = "90",
    dribbling = "86",
    reactions = "90",
    composure = "89",

    standingtackle = "56",
    slidingtackle = "53",
    interceptions = "65",
    defensiveawareness = "47",
    aggression = "79",

    finishing = "83",
    shotpower = "87",
    longshots = "94",
    volleys = "86",
    penalties = "78",
    headingaccuracy = "62",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "4200204",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Wesley",
    surname = "Sneijder",
    playerjerseyname = "Sneijder"
})

Log("Created FICTIVE Ultimate Scream Hero Wesley Sneijder (18 yo)")
