-- Ultimate Scream Hero Marek Hamšík (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 171877
-- Card UID : 20212
-- Fictive Player ID : 46007
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46007
local real_playerid = 171877
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "43",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "183",
    weight = "73",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "85",
    stamina = "92",
    agility = "80",
    balance = "85",
    jumping = "81",
    strength = "82",

    shortpassing = "92",
    longpassing = "90",
    vision = "87",
    curve = "82",

    ballcontrol = "89",
    dribbling = "88",
    reactions = "87",
    composure = "88",

    standingtackle = "81",
    slidingtackle = "76",
    interceptions = "83",
    defensiveawareness = "77",
    aggression = "79",

    finishing = "86",
    shotpower = "91",
    longshots = "90",
    volleys = "83",
    penalties = "84",
    headingaccuracy = "83",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "83887108",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Marek",
    surname = "Hamšík",
    playerjerseyname = "Hamšík"
})

Log("Created FICTIVE Ultimate Scream Hero Marek Hamšík (18 yo)")
