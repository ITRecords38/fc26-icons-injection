-- Ultimate Scream Hero Javier Mascherano (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 142754
-- Card UID : 20202
-- Fictive Player ID : 46004
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46004
local real_playerid = 142754
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "73",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "78",
    sprintspeed = "78",
    stamina = "89",
    agility = "78",
    balance = "81",
    jumping = "89",
    strength = "83",

    shortpassing = "88",
    longpassing = "86",
    vision = "80",
    curve = "68",

    ballcontrol = "85",
    dribbling = "78",
    reactions = "90",
    composure = "86",

    standingtackle = "92",
    slidingtackle = "93",
    interceptions = "92",
    defensiveawareness = "91",
    aggression = "92",

    finishing = "45",
    shotpower = "78",
    longshots = "86",
    volleys = "54",
    penalties = "62",
    headingaccuracy = "77",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "330752",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Javier",
    surname = "Mascherano",
    playerjerseyname = "Mascherano"
})

Log("Created FICTIVE Ultimate Scream Hero Javier Mascherano (18 yo)")
