-- Ultimate Scream Hero Freddie Ljungberg (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 6975
-- Card UID : 20359
-- Fictive Player ID : 46016
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46016
local real_playerid = 6975
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "46",

    preferredposition1 = "12",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "73",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "91",
    sprintspeed = "89",
    stamina = "89",
    agility = "85",
    balance = "81",
    jumping = "71",
    strength = "77",

    shortpassing = "85",
    longpassing = "76",
    vision = "84",
    curve = "84",

    ballcontrol = "87",
    dribbling = "89",
    reactions = "87",
    composure = "80",

    standingtackle = "44",
    slidingtackle = "38",
    interceptions = "46",
    defensiveawareness = "50",
    aggression = "76",

    finishing = "87",
    shotpower = "80",
    longshots = "76",
    volleys = "71",
    penalties = "72",
    headingaccuracy = "61",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "2098434",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Freddie",
    surname = "Ljungberg",
    playerjerseyname = "Ljungberg"
})

Log("Created FICTIVE Ultimate Scream Hero Freddie Ljungberg (18 yo)")
