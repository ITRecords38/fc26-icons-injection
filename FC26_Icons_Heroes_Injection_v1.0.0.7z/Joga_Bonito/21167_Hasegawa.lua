-- Joga Bonito Yui Hasegawa (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 245830
-- Card UID : 21167
-- Fictive Player ID : 46038
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46038
local real_playerid = 245830
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "163",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "156",
    weight = "48",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "87",
    stamina = "88",
    agility = "86",
    balance = "90",
    jumping = "67",
    strength = "57",

    shortpassing = "92",
    longpassing = "91",
    vision = "92",
    curve = "70",

    ballcontrol = "88",
    dribbling = "90",
    reactions = "87",
    composure = "82",

    standingtackle = "88",
    slidingtackle = "80",
    interceptions = "90",
    defensiveawareness = "90",
    aggression = "81",

    finishing = "75",
    shotpower = "82",
    longshots = "91",
    volleys = "77",
    penalties = "71",
    headingaccuracy = "50",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "17900352",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Yui",
    surname = "Hasegawa",
    playerjerseyname = "Hasegawa"
})

Log("Created FICTIVE Joga Bonito Yui Hasegawa (18 yo)")
