-- Joga Bonito Rayan Cherki (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 251570
-- Card UID : 20803
-- Fictive Player ID : 46019
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46019
local real_playerid = 251570
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "23",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "177",
    weight = "71",
    preferredfoot = "2",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "84",
    sprintspeed = "84",
    stamina = "80",
    agility = "85",
    balance = "90",
    jumping = "64",
    strength = "72",

    shortpassing = "89",
    longpassing = "83",
    vision = "94",
    curve = "87",

    ballcontrol = "92",
    dribbling = "95",
    reactions = "82",
    composure = "90",

    standingtackle = "33",
    slidingtackle = "21",
    interceptions = "31",
    defensiveawareness = "27",
    aggression = "64",

    finishing = "84",
    shotpower = "90",
    longshots = "83",
    volleys = "80",
    penalties = "74",
    headingaccuracy = "40",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "13640002",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Rayan",
    surname = "Cherki",
    playerjerseyname = "Cherki"
})

Log("Created FICTIVE Joga Bonito Rayan Cherki (18 yo)")
