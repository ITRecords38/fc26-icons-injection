-- Joga Bonito Ederson Santana de Moraes (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 210257
-- Card UID : 20805
-- Fictive Player ID : 46021
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46021
local real_playerid = 210257
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "188",
    weight = "86",
    preferredfoot = "2",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "70",
    sprintspeed = "70",
    stamina = "44",
    agility = "60",
    balance = "48",
    jumping = "78",
    strength = "78",

    shortpassing = "65",
    longpassing = "68",
    vision = "70",
    curve = "39",

    ballcontrol = "45",
    dribbling = "30",
    reactions = "82",
    composure = "70",

    standingtackle = "15",
    slidingtackle = "8",
    interceptions = "27",
    defensiveawareness = "29",
    aggression = "38",

    finishing = "14",
    shotpower = "68",
    longshots = "68",
    volleys = "18",
    penalties = "65",
    headingaccuracy = "14",

    skillmoves = "4",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1024",
    trait2 = "54",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Ederson Santana de",
    surname = "Moraes",
    playerjerseyname = "Moraes"
})

Log("Created FICTIVE Joga Bonito Ederson Santana de Moraes (18 yo)")
