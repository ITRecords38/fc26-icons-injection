-- Joga Bonito Endrick Felipe Moreira de Sousa (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 272505
-- Card UID : 20808
-- Fictive Player ID : 46024
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46024
local real_playerid = 272505
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "173",
    weight = "66",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "92",
    sprintspeed = "90",
    stamina = "82",
    agility = "88",
    balance = "86",
    jumping = "93",
    strength = "82",

    shortpassing = "84",
    longpassing = "73",
    vision = "82",
    curve = "82",

    ballcontrol = "85",
    dribbling = "86",
    reactions = "85",
    composure = "83",

    standingtackle = "40",
    slidingtackle = "41",
    interceptions = "27",
    defensiveawareness = "32",
    aggression = "70",

    finishing = "86",
    shotpower = "87",
    longshots = "73",
    volleys = "82",
    penalties = "75",
    headingaccuracy = "93",

    skillmoves = "4",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "35651717",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Endrick Felipe Moreira de",
    surname = "Sousa",
    playerjerseyname = "Sousa"
})

Log("Created FICTIVE Joga Bonito Endrick Felipe Moreira de Sousa (18 yo)")
