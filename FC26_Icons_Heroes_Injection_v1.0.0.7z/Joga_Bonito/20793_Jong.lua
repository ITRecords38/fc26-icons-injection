-- Joga Bonito Frenkie de Jong (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 228702
-- Card UID : 20793
-- Fictive Player ID : 46009
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46009
local real_playerid = 228702
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "34",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "181",
    weight = "74",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "85",
    stamina = "92",
    agility = "89",
    balance = "81",
    jumping = "87",
    strength = "80",

    shortpassing = "92",
    longpassing = "89",
    vision = "90",
    curve = "86",

    ballcontrol = "90",
    dribbling = "88",
    reactions = "89",
    composure = "92",

    standingtackle = "85",
    slidingtackle = "84",
    interceptions = "89",
    defensiveawareness = "83",
    aggression = "80",

    finishing = "77",
    shotpower = "70",
    longshots = "89",
    volleys = "72",
    penalties = "54",
    headingaccuracy = "80",

    skillmoves = "4",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "17968640",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Frenkie de",
    surname = "Jong",
    playerjerseyname = "Jong"
})

Log("Created FICTIVE Joga Bonito Frenkie de Jong (18 yo)")
