-- Joga Bonito Aitana Bonmatí Conca (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 241667
-- Card UID : 20789
-- Fictive Player ID : 46005
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46005
local real_playerid = 241667
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "163",
    weight = "53",
    preferredfoot = "1",

    overallrating = "91",
    potential = "91",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "87",
    stamina = "83",
    agility = "93",
    balance = "86",
    jumping = "77",
    strength = "76",

    shortpassing = "92",
    longpassing = "91",
    vision = "91",
    curve = "80",

    ballcontrol = "91",
    dribbling = "92",
    reactions = "91",
    composure = "85",

    standingtackle = "81",
    slidingtackle = "67",
    interceptions = "88",
    defensiveawareness = "75",
    aggression = "65",

    finishing = "91",
    shotpower = "79",
    longshots = "91",
    volleys = "80",
    penalties = "70",
    headingaccuracy = "54",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "5251904",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Aitana Bonmatí",
    surname = "Conca",
    playerjerseyname = "Conca"
})

Log("Created FICTIVE Joga Bonito Aitana Bonmatí Conca (18 yo)")
