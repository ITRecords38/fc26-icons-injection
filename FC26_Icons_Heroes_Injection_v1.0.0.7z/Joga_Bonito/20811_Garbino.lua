-- Joga Bonito Maëlle Garbino (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 265861
-- Card UID : 20811
-- Fictive Player ID : 46027
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46027
local real_playerid = 265861
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "12",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "162",
    weight = "54",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "84",
    sprintspeed = "87",
    stamina = "87",
    agility = "84",
    balance = "87",
    jumping = "70",
    strength = "66",

    shortpassing = "90",
    longpassing = "85",
    vision = "87",
    curve = "81",

    ballcontrol = "89",
    dribbling = "84",
    reactions = "82",
    composure = "84",

    standingtackle = "63",
    slidingtackle = "46",
    interceptions = "64",
    defensiveawareness = "60",
    aggression = "60",

    finishing = "93",
    shotpower = "74",
    longshots = "85",
    volleys = "72",
    penalties = "71",
    headingaccuracy = "60",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "72353920",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Maëlle",
    surname = "Garbino",
    playerjerseyname = "Garbino"
})

Log("Created FICTIVE Joga Bonito Maëlle Garbino (18 yo)")
