-- Joga Bonito Hernán López Muñoz (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 248231
-- Card UID : 21176
-- Fictive Player ID : 46045
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46045
local real_playerid = 248231
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "168",
    weight = "67",
    preferredfoot = "2",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "87",
    stamina = "80",
    agility = "90",
    balance = "93",
    jumping = "75",
    strength = "70",

    shortpassing = "88",
    longpassing = "89",
    vision = "90",
    curve = "74",

    ballcontrol = "85",
    dribbling = "89",
    reactions = "80",
    composure = "83",

    standingtackle = "55",
    slidingtackle = "52",
    interceptions = "39",
    defensiveawareness = "45",
    aggression = "64",

    finishing = "81",
    shotpower = "90",
    longshots = "89",
    volleys = "77",
    penalties = "70",
    headingaccuracy = "52",

    skillmoves = "4",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "96469760",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Hernán López",
    surname = "Muñoz",
    playerjerseyname = "Muñoz"
})

Log("Created FICTIVE Joga Bonito Hernán López Muñoz (18 yo)")
