-- Moments Oliver Provstgaard (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 266123
-- Card UID : 20637
-- Fictive Player ID : 46007
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46007
local real_playerid = 266123
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "13",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "192",
    weight = "86",
    preferredfoot = "2",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "79",
    sprintspeed = "80",
    stamina = "82",
    agility = "70",
    balance = "74",
    jumping = "86",
    strength = "90",

    shortpassing = "86",
    longpassing = "84",
    vision = "69",
    curve = "62",

    ballcontrol = "77",
    dribbling = "70",
    reactions = "82",
    composure = "81",

    standingtackle = "87",
    slidingtackle = "84",
    interceptions = "83",
    defensiveawareness = "85",
    aggression = "80",

    finishing = "53",
    shotpower = "80",
    longshots = "84",
    volleys = "60",
    penalties = "60",
    headingaccuracy = "86",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "918016",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Oliver",
    surname = "Provstgaard",
    playerjerseyname = "Provstgaard"
})

Log("Created FICTIVE Moments Oliver Provstgaard (18 yo)")
