-- FC Pro Fabián Ruiz Peña (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 226271
-- Card UID : 20604
-- Fictive Player ID : 46005
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46005
local real_playerid = 226271
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "189",
    weight = "70",
    preferredfoot = "2",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "81",
    sprintspeed = "81",
    stamina = "90",
    agility = "80",
    balance = "80",
    jumping = "75",
    strength = "72",

    shortpassing = "91",
    longpassing = "88",
    vision = "90",
    curve = "84",

    ballcontrol = "90",
    dribbling = "87",
    reactions = "90",
    composure = "88",

    standingtackle = "82",
    slidingtackle = "78",
    interceptions = "82",
    defensiveawareness = "74",
    aggression = "73",

    finishing = "82",
    shotpower = "84",
    longshots = "88",
    volleys = "72",
    penalties = "72",
    headingaccuracy = "71",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "20972545",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Fabián Ruiz",
    surname = "Peña",
    playerjerseyname = "Peña"
})

Log("Created FICTIVE FC Pro Fabián Ruiz Peña (18 yo)")
