-- FC Pro Eric Maxim Choupo-Moting (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 183569
-- Card UID : 20626
-- Fictive Player ID : 46021
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46021
local real_playerid = 183569
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "103",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "191",
    weight = "90",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "81",
    sprintspeed = "84",
    stamina = "80",
    agility = "81",
    balance = "80",
    jumping = "90",
    strength = "92",

    shortpassing = "85",
    longpassing = "74",
    vision = "83",
    curve = "85",

    ballcontrol = "84",
    dribbling = "87",
    reactions = "83",
    composure = "83",

    standingtackle = "45",
    slidingtackle = "25",
    interceptions = "51",
    defensiveawareness = "39",
    aggression = "73",

    finishing = "88",
    shotpower = "91",
    longshots = "74",
    volleys = "86",
    penalties = "78",
    headingaccuracy = "91",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "538443844",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Eric Maxim",
    surname = "Choupo-Moting",
    playerjerseyname = "Choupo-Moting"
})

Log("Created FICTIVE FC Pro Eric Maxim Choupo-Moting (18 yo)")
