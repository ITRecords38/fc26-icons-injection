-- FC Pro Gleison Bremer Silva Nascimento (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 239580
-- Card UID : 20615
-- Fictive Player ID : 46012
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46012
local real_playerid = 239580
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "84",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "79",
    sprintspeed = "87",
    stamina = "75",
    agility = "68",
    balance = "67",
    jumping = "93",
    strength = "85",

    shortpassing = "86",
    longpassing = "78",
    vision = "53",
    curve = "50",

    ballcontrol = "70",
    dribbling = "68",
    reactions = "80",
    composure = "80",

    standingtackle = "88",
    slidingtackle = "85",
    interceptions = "85",
    defensiveawareness = "88",
    aggression = "85",

    finishing = "51",
    shotpower = "71",
    longshots = "78",
    volleys = "39",
    penalties = "44",
    headingaccuracy = "88",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268469264",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Gleison Bremer Silva",
    surname = "Nascimento",
    playerjerseyname = "Nascimento"
})

Log("Created FICTIVE FC Pro Gleison Bremer Silva Nascimento (18 yo)")
