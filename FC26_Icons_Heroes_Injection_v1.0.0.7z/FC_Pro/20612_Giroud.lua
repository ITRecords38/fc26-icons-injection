-- FC Pro Olivier Giroud (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 178509
-- Card UID : 20612
-- Fictive Player ID : 46009
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46009
local real_playerid = 178509
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "193",
    weight = "91",
    preferredfoot = "2",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "83",
    stamina = "78",
    agility = "80",
    balance = "78",
    jumping = "90",
    strength = "92",

    shortpassing = "85",
    longpassing = "72",
    vision = "88",
    curve = "82",

    ballcontrol = "88",
    dribbling = "80",
    reactions = "91",
    composure = "92",

    standingtackle = "44",
    slidingtackle = "24",
    interceptions = "50",
    defensiveawareness = "44",
    aggression = "82",

    finishing = "87",
    shotpower = "90",
    longshots = "72",
    volleys = "92",
    penalties = "96",
    headingaccuracy = "94",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "537395344",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Olivier",
    surname = "Giroud",
    playerjerseyname = "Giroud"
})

Log("Created FICTIVE FC Pro Olivier Giroud (18 yo)")
