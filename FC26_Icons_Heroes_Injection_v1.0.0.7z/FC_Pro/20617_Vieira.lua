-- FC Pro Fábio Daniel Ferreira Vieira (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 256958
-- Card UID : 20617
-- Fictive Player ID : 46014
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46014
local real_playerid = 256958
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "38",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "176",
    weight = "61",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "83",
    stamina = "73",
    agility = "85",
    balance = "80",
    jumping = "64",
    strength = "60",

    shortpassing = "90",
    longpassing = "87",
    vision = "90",
    curve = "82",

    ballcontrol = "88",
    dribbling = "87",
    reactions = "84",
    composure = "84",

    standingtackle = "69",
    slidingtackle = "55",
    interceptions = "66",
    defensiveawareness = "65",
    aggression = "59",

    finishing = "82",
    shotpower = "86",
    longshots = "87",
    volleys = "74",
    penalties = "77",
    headingaccuracy = "53",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "16780552",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Fábio Daniel Ferreira",
    surname = "Vieira",
    playerjerseyname = "Vieira"
})

Log("Created FICTIVE FC Pro Fábio Daniel Ferreira Vieira (18 yo)")
