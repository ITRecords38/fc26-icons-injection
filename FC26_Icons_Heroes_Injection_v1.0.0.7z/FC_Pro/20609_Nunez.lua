-- FC Pro Darwin Núñez (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 253072
-- Card UID : 20609
-- Fictive Player ID : 46008
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46008
local real_playerid = 253072
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "60",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "81",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "92",
    stamina = "82",
    agility = "76",
    balance = "77",
    jumping = "96",
    strength = "84",

    shortpassing = "83",
    longpassing = "77",
    vision = "86",
    curve = "82",

    ballcontrol = "84",
    dribbling = "86",
    reactions = "82",
    composure = "85",

    standingtackle = "59",
    slidingtackle = "45",
    interceptions = "52",
    defensiveawareness = "48",
    aggression = "87",

    finishing = "85",
    shotpower = "96",
    longshots = "77",
    volleys = "82",
    penalties = "86",
    headingaccuracy = "87",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "102760450",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Darwin",
    surname = "Núñez",
    playerjerseyname = "Núñez"
})

Log("Created FICTIVE FC Pro Darwin Núñez (18 yo)")
