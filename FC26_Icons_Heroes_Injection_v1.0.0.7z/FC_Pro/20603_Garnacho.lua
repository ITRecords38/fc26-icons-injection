-- FC Pro Alejandro Garnacho (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 268438
-- Card UID : 20603
-- Fictive Player ID : 46004
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46004
local real_playerid = 268438
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "72",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "86",
    stamina = "88",
    agility = "94",
    balance = "95",
    jumping = "72",
    strength = "60",

    shortpassing = "83",
    longpassing = "74",
    vision = "82",
    curve = "84",

    ballcontrol = "85",
    dribbling = "86",
    reactions = "83",
    composure = "78",

    standingtackle = "47",
    slidingtackle = "37",
    interceptions = "51",
    defensiveawareness = "46",
    aggression = "77",

    finishing = "82",
    shotpower = "83",
    longshots = "74",
    volleys = "84",
    penalties = "60",
    headingaccuracy = "56",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "3153953",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Alejandro",
    surname = "Garnacho",
    playerjerseyname = "Garnacho"
})

Log("Created FICTIVE FC Pro Alejandro Garnacho (18 yo)")
