-- Winter Wildcards Morgan Rogers (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 260247
-- Card UID : 21505
-- Fictive Player ID : 46039
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46039
local real_playerid = 260247
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "188",
    weight = "80",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "80",
    sprintspeed = "85",
    stamina = "90",
    agility = "84",
    balance = "83",
    jumping = "85",
    strength = "86",

    shortpassing = "90",
    longpassing = "85",
    vision = "90",
    curve = "83",

    ballcontrol = "88",
    dribbling = "90",
    reactions = "86",
    composure = "89",

    standingtackle = "77",
    slidingtackle = "53",
    interceptions = "73",
    defensiveawareness = "73",
    aggression = "75",

    finishing = "86",
    shotpower = "82",
    longshots = "85",
    volleys = "80",
    penalties = "65",
    headingaccuracy = "70",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "550504960",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Morgan",
    surname = "Rogers",
    playerjerseyname = "Rogers"
})

Log("Created FICTIVE Winter Wildcards Morgan Rogers (18 yo)")
