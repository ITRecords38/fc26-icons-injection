-- Winter Wildcards Larissa Mühlhaus (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 73023
-- Card UID : 21430
-- Fictive Player ID : 46027
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46027
local real_playerid = 73023
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "177",
    weight = "71",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "84",
    sprintspeed = "86",
    stamina = "85",
    agility = "84",
    balance = "84",
    jumping = "92",
    strength = "99",

    shortpassing = "93",
    longpassing = "90",
    vision = "88",
    curve = "90",

    ballcontrol = "87",
    dribbling = "84",
    reactions = "87",
    composure = "84",

    standingtackle = "69",
    slidingtackle = "38",
    interceptions = "60",
    defensiveawareness = "48",
    aggression = "99",

    finishing = "87",
    shotpower = "86",
    longshots = "90",
    volleys = "76",
    penalties = "63",
    headingaccuracy = "95",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "2119",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Larissa",
    surname = "Mühlhaus",
    playerjerseyname = "Mühlhaus"
})

Log("Created FICTIVE Winter Wildcards Larissa Mühlhaus (18 yo)")
