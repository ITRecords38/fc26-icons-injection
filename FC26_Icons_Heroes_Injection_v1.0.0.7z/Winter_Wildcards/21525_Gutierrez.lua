-- Winter Wildcards Patricia Guijarro Gutiérrez (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 237289
-- Card UID : 21525
-- Fictive Player ID : 46049
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46049
local real_playerid = 237289
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "170",
    weight = "73",
    preferredfoot = "1",

    overallrating = "90",
    potential = "90",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "83",
    stamina = "84",
    agility = "86",
    balance = "90",
    jumping = "91",
    strength = "86",

    shortpassing = "91",
    longpassing = "93",
    vision = "87",
    curve = "76",

    ballcontrol = "93",
    dribbling = "89",
    reactions = "89",
    composure = "87",

    standingtackle = "89",
    slidingtackle = "87",
    interceptions = "86",
    defensiveawareness = "88",
    aggression = "83",

    finishing = "81",
    shotpower = "90",
    longshots = "93",
    volleys = "60",
    penalties = "71",
    headingaccuracy = "86",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "21507328",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Patricia Guijarro",
    surname = "Gutiérrez",
    playerjerseyname = "Gutiérrez"
})

Log("Created FICTIVE Winter Wildcards Patricia Guijarro Gutiérrez (18 yo)")
