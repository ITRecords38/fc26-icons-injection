-- Winter Wildcards Kingsley Coman (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 213345
-- Card UID : 21421
-- Fictive Player ID : 46018
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46018
local real_playerid = 213345
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "181",
    weight = "75",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "93",
    sprintspeed = "87",
    stamina = "80",
    agility = "94",
    balance = "88",
    jumping = "84",
    strength = "70",

    shortpassing = "86",
    longpassing = "80",
    vision = "86",
    curve = "89",

    ballcontrol = "90",
    dribbling = "91",
    reactions = "85",
    composure = "81",

    standingtackle = "32",
    slidingtackle = "25",
    interceptions = "27",
    defensiveawareness = "34",
    aggression = "55",

    finishing = "81",
    shotpower = "91",
    longshots = "80",
    volleys = "86",
    penalties = "72",
    headingaccuracy = "71",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "47186496",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Kingsley",
    surname = "Coman",
    playerjerseyname = "Coman"
})

Log("Created FICTIVE Winter Wildcards Kingsley Coman (18 yo)")
