-- Winter Wildcards Rodrygo Silva de Goes (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 243812
-- Card UID : 21496
-- Fictive Player ID : 46032
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46032
local real_playerid = 243812
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "23",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "64",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "94",
    sprintspeed = "93",
    stamina = "88",
    agility = "91",
    balance = "89",
    jumping = "86",
    strength = "70",

    shortpassing = "86",
    longpassing = "81",
    vision = "91",
    curve = "89",

    ballcontrol = "91",
    dribbling = "92",
    reactions = "87",
    composure = "89",

    standingtackle = "39",
    slidingtackle = "35",
    interceptions = "24",
    defensiveawareness = "28",
    aggression = "65",

    finishing = "91",
    shotpower = "83",
    longshots = "81",
    volleys = "73",
    penalties = "89",
    headingaccuracy = "78",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "34612105",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Rodrygo Silva de",
    surname = "Goes",
    playerjerseyname = "Goes"
})

Log("Created FICTIVE Winter Wildcards Rodrygo Silva de Goes (18 yo)")
