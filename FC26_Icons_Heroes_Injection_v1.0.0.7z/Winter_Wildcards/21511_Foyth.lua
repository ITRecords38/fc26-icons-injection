-- Winter Wildcards Juan Foyth (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 237221
-- Card UID : 21511
-- Fictive Player ID : 46045
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46045
local real_playerid = 237221
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "83",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "81",
    sprintspeed = "82",
    stamina = "76",
    agility = "80",
    balance = "81",
    jumping = "94",
    strength = "86",

    shortpassing = "92",
    longpassing = "81",
    vision = "77",
    curve = "71",

    ballcontrol = "88",
    dribbling = "81",
    reactions = "91",
    composure = "80",

    standingtackle = "87",
    slidingtackle = "86",
    interceptions = "85",
    defensiveawareness = "85",
    aggression = "89",

    finishing = "81",
    shotpower = "82",
    longshots = "81",
    volleys = "72",
    penalties = "82",
    headingaccuracy = "84",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "826572800",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Juan",
    surname = "Foyth",
    playerjerseyname = "Foyth"
})

Log("Created FICTIVE Winter Wildcards Juan Foyth (18 yo)")
