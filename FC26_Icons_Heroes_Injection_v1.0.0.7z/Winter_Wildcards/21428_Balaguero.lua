-- Winter Wildcards Gerard Moreno Balagueró (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 208093
-- Card UID : 21428
-- Fictive Player ID : 46025
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46025
local real_playerid = 208093
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "77",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "84",
    sprintspeed = "84",
    stamina = "85",
    agility = "82",
    balance = "81",
    jumping = "90",
    strength = "81",

    shortpassing = "84",
    longpassing = "80",
    vision = "82",
    curve = "82",

    ballcontrol = "87",
    dribbling = "87",
    reactions = "86",
    composure = "84",

    standingtackle = "45",
    slidingtackle = "45",
    interceptions = "47",
    defensiveawareness = "49",
    aggression = "70",

    finishing = "85",
    shotpower = "99",
    longshots = "80",
    volleys = "81",
    penalties = "87",
    headingaccuracy = "86",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "17827907",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Gerard Moreno",
    surname = "Balagueró",
    playerjerseyname = "Balagueró"
})

Log("Created FICTIVE Winter Wildcards Gerard Moreno Balagueró (18 yo)")
