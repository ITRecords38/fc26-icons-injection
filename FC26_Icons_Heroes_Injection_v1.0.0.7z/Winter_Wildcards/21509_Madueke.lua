-- Winter Wildcards Noni Madueke (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 254796
-- Card UID : 21509
-- Fictive Player ID : 46043
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46043
local real_playerid = 254796
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "182",
    weight = "75",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "93",
    sprintspeed = "92",
    stamina = "84",
    agility = "85",
    balance = "83",
    jumping = "84",
    strength = "74",

    shortpassing = "82",
    longpassing = "72",
    vision = "81",
    curve = "82",

    ballcontrol = "87",
    dribbling = "89",
    reactions = "80",
    composure = "81",

    standingtackle = "52",
    slidingtackle = "35",
    interceptions = "52",
    defensiveawareness = "52",
    aggression = "74",

    finishing = "85",
    shotpower = "90",
    longshots = "72",
    volleys = "74",
    penalties = "84",
    headingaccuracy = "64",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "36700384",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Noni",
    surname = "Madueke",
    playerjerseyname = "Madueke"
})

Log("Created FICTIVE Winter Wildcards Noni Madueke (18 yo)")
