-- Winter Wildcards Ousmane Dembélé (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 231443
-- Card UID : 21409
-- Fictive Player ID : 46006
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46006
local real_playerid = 231443
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "178",
    weight = "67",
    preferredfoot = "2",

    overallrating = "91",
    potential = "91",
    internationalrep = "3",

    acceleration = "95",
    sprintspeed = "91",
    stamina = "79",
    agility = "96",
    balance = "83",
    jumping = "88",
    strength = "72",

    shortpassing = "90",
    longpassing = "79",
    vision = "85",
    curve = "86",

    ballcontrol = "96",
    dribbling = "96",
    reactions = "93",
    composure = "90",

    standingtackle = "50",
    slidingtackle = "40",
    interceptions = "46",
    defensiveawareness = "50",
    aggression = "61",

    finishing = "92",
    shotpower = "93",
    longshots = "79",
    volleys = "81",
    penalties = "82",
    headingaccuracy = "75",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "44048897",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Ousmane",
    surname = "Dembélé",
    playerjerseyname = "Dembélé"
})

Log("Created FICTIVE Winter Wildcards Ousmane Dembélé (18 yo)")
