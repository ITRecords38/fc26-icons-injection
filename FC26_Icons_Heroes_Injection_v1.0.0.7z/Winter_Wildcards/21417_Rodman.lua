-- Winter Wildcards Trinity Rodman (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 266928
-- Card UID : 21417
-- Fictive Player ID : 46014
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46014
local real_playerid = 266928
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "95",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "173",
    weight = "60",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "92",
    stamina = "88",
    agility = "90",
    balance = "86",
    jumping = "91",
    strength = "85",

    shortpassing = "84",
    longpassing = "69",
    vision = "87",
    curve = "74",

    ballcontrol = "89",
    dribbling = "84",
    reactions = "87",
    composure = "83",

    standingtackle = "70",
    slidingtackle = "65",
    interceptions = "70",
    defensiveawareness = "65",
    aggression = "84",

    finishing = "90",
    shotpower = "89",
    longshots = "69",
    volleys = "77",
    penalties = "83",
    headingaccuracy = "88",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "111681600",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Trinity",
    surname = "Rodman",
    playerjerseyname = "Rodman"
})

Log("Created FICTIVE Winter Wildcards Trinity Rodman (18 yo)")
