-- Winter Wildcards Charlie Cresswell (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 254121
-- Card UID : 21545
-- Fictive Player ID : 46067
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46067
local real_playerid = 254121
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "191",
    weight = "77",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "81",
    stamina = "80",
    agility = "70",
    balance = "70",
    jumping = "93",
    strength = "87",

    shortpassing = "86",
    longpassing = "87",
    vision = "99",
    curve = "66",

    ballcontrol = "74",
    dribbling = "70",
    reactions = "86",
    composure = "88",

    standingtackle = "90",
    slidingtackle = "84",
    interceptions = "80",
    defensiveawareness = "84",
    aggression = "83",

    finishing = "31",
    shotpower = "73",
    longshots = "87",
    volleys = "31",
    penalties = "54",
    headingaccuracy = "88",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "885264",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Charlie",
    surname = "Cresswell",
    playerjerseyname = "Cresswell"
})

Log("Created FICTIVE Winter Wildcards Charlie Cresswell (18 yo)")
