-- Winter Wildcards Federico Valverde (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 239053
-- Card UID : 21411
-- Fictive Player ID : 46008
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46008
local real_playerid = 239053
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "60",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "182",
    weight = "74",
    preferredfoot = "1",

    overallrating = "90",
    potential = "90",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "94",
    stamina = "95",
    agility = "80",
    balance = "80",
    jumping = "84",
    strength = "84",

    shortpassing = "90",
    longpassing = "90",
    vision = "88",
    curve = "78",

    ballcontrol = "89",
    dribbling = "85",
    reactions = "90",
    composure = "85",

    standingtackle = "88",
    slidingtackle = "87",
    interceptions = "87",
    defensiveawareness = "83",
    aggression = "83",

    finishing = "81",
    shotpower = "92",
    longshots = "90",
    volleys = "79",
    penalties = "60",
    headingaccuracy = "64",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "70059012",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Federico",
    surname = "Valverde",
    playerjerseyname = "Valverde"
})

Log("Created FICTIVE Winter Wildcards Federico Valverde (18 yo)")
