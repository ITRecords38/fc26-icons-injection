-- Winter Wildcards Nico Schlotterbeck (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 247819
-- Card UID : 21504
-- Fictive Player ID : 46038
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46038
local real_playerid = 247819
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "191",
    weight = "86",
    preferredfoot = "2",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "81",
    stamina = "78",
    agility = "75",
    balance = "75",
    jumping = "92",
    strength = "86",

    shortpassing = "83",
    longpassing = "92",
    vision = "81",
    curve = "80",

    ballcontrol = "72",
    dribbling = "75",
    reactions = "85",
    composure = "85",

    standingtackle = "89",
    slidingtackle = "89",
    interceptions = "85",
    defensiveawareness = "87",
    aggression = "85",

    finishing = "53",
    shotpower = "84",
    longshots = "92",
    volleys = "58",
    penalties = "39",
    headingaccuracy = "86",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "902144",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Nico",
    surname = "Schlotterbeck",
    playerjerseyname = "Schlotterbeck"
})

Log("Created FICTIVE Winter Wildcards Nico Schlotterbeck (18 yo)")
