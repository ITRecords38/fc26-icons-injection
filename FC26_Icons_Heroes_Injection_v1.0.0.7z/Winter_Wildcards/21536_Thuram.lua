-- Winter Wildcards Khéphren Thuram (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 247246
-- Card UID : 21536
-- Fictive Player ID : 46058
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46058
local real_playerid = 247246
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "192",
    weight = "80",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "85",
    stamina = "87",
    agility = "84",
    balance = "82",
    jumping = "93",
    strength = "85",

    shortpassing = "92",
    longpassing = "88",
    vision = "86",
    curve = "80",

    ballcontrol = "88",
    dribbling = "86",
    reactions = "84",
    composure = "88",

    standingtackle = "90",
    slidingtackle = "81",
    interceptions = "87",
    defensiveawareness = "86",
    aggression = "90",

    finishing = "83",
    shotpower = "85",
    longshots = "88",
    volleys = "70",
    penalties = "65",
    headingaccuracy = "82",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "83900160",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Khéphren",
    surname = "Thuram",
    playerjerseyname = "Thuram"
})

Log("Created FICTIVE Winter Wildcards Khéphren Thuram (18 yo)")
