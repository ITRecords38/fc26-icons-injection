-- Winter Wildcards Nicholas Williams Arthuer (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 256516
-- Card UID : 21530
-- Fictive Player ID : 46052
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46052
local real_playerid = 256516
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "181",
    weight = "67",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "96",
    sprintspeed = "94",
    stamina = "92",
    agility = "94",
    balance = "86",
    jumping = "88",
    strength = "70",

    shortpassing = "84",
    longpassing = "76",
    vision = "84",
    curve = "83",

    ballcontrol = "87",
    dribbling = "90",
    reactions = "84",
    composure = "80",

    standingtackle = "31",
    slidingtackle = "28",
    interceptions = "44",
    defensiveawareness = "40",
    aggression = "65",

    finishing = "88",
    shotpower = "88",
    longshots = "76",
    volleys = "72",
    penalties = "69",
    headingaccuracy = "72",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "102768705",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Nicholas Williams",
    surname = "Arthuer",
    playerjerseyname = "Arthuer"
})

Log("Created FICTIVE Winter Wildcards Nicholas Williams Arthuer (18 yo)")
