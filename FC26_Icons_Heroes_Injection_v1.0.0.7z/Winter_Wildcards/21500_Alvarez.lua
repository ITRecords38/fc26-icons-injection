-- Winter Wildcards Julián Alvarez (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 246191
-- Card UID : 21500
-- Fictive Player ID : 46034
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46034
local real_playerid = 246191
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "170",
    weight = "71",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "88",
    sprintspeed = "87",
    stamina = "88",
    agility = "90",
    balance = "90",
    jumping = "89",
    strength = "75",

    shortpassing = "87",
    longpassing = "82",
    vision = "87",
    curve = "91",

    ballcontrol = "91",
    dribbling = "90",
    reactions = "91",
    composure = "90",

    standingtackle = "58",
    slidingtackle = "48",
    interceptions = "55",
    defensiveawareness = "63",
    aggression = "89",

    finishing = "91",
    shotpower = "91",
    longshots = "82",
    volleys = "87",
    penalties = "81",
    headingaccuracy = "82",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "22020361",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Julián",
    surname = "Alvarez",
    playerjerseyname = "Alvarez"
})

Log("Created FICTIVE Winter Wildcards Julián Alvarez (18 yo)")
