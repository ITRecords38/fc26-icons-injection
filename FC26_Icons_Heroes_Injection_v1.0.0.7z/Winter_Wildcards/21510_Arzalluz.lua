-- Winter Wildcards Álvaro Odriozola Arzalluz (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 234035
-- Card UID : 21510
-- Fictive Player ID : 46044
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46044
local real_playerid = 234035
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "176",
    weight = "66",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "84",
    sprintspeed = "88",
    stamina = "85",
    agility = "83",
    balance = "88",
    jumping = "82",
    strength = "78",

    shortpassing = "84",
    longpassing = "83",
    vision = "75",
    curve = "84",

    ballcontrol = "86",
    dribbling = "87",
    reactions = "84",
    composure = "84",

    standingtackle = "84",
    slidingtackle = "84",
    interceptions = "83",
    defensiveawareness = "83",
    aggression = "80",

    finishing = "58",
    shotpower = "73",
    longshots = "83",
    volleys = "58",
    penalties = "74",
    headingaccuracy = "82",

    skillmoves = "2",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "7504384",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Álvaro Odriozola",
    surname = "Arzalluz",
    playerjerseyname = "Arzalluz"
})

Log("Created FICTIVE Winter Wildcards Álvaro Odriozola Arzalluz (18 yo)")
