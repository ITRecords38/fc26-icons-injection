-- Winter Wildcards Samson Baidoo (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 270997
-- Card UID : 21512
-- Fictive Player ID : 46046
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46046
local real_playerid = 270997
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "4",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "86",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "82",
    stamina = "82",
    agility = "77",
    balance = "78",
    jumping = "84",
    strength = "99",

    shortpassing = "85",
    longpassing = "80",
    vision = "70",
    curve = "42",

    ballcontrol = "86",
    dribbling = "78",
    reactions = "83",
    composure = "83",

    standingtackle = "89",
    slidingtackle = "86",
    interceptions = "81",
    defensiveawareness = "85",
    aggression = "84",

    finishing = "35",
    shotpower = "62",
    longshots = "80",
    volleys = "44",
    penalties = "55",
    headingaccuracy = "83",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "377856",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Samson",
    surname = "Baidoo",
    playerjerseyname = "Baidoo"
})

Log("Created FICTIVE Winter Wildcards Samson Baidoo (18 yo)")
