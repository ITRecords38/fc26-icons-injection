-- Winter Wildcards Patrik Schick (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 234236
-- Card UID : 21532
-- Fictive Player ID : 46054
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46054
local real_playerid = 234236
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "12",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "191",
    weight = "87",
    preferredfoot = "2",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "85",
    stamina = "80",
    agility = "85",
    balance = "80",
    jumping = "96",
    strength = "90",

    shortpassing = "88",
    longpassing = "72",
    vision = "85",
    curve = "88",

    ballcontrol = "88",
    dribbling = "86",
    reactions = "90",
    composure = "90",

    standingtackle = "31",
    slidingtackle = "21",
    interceptions = "27",
    defensiveawareness = "47",
    aggression = "70",

    finishing = "91",
    shotpower = "90",
    longshots = "72",
    volleys = "89",
    penalties = "65",
    headingaccuracy = "96",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "4194644",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Patrik",
    surname = "Schick",
    playerjerseyname = "Schick"
})

Log("Created FICTIVE Winter Wildcards Patrik Schick (18 yo)")
