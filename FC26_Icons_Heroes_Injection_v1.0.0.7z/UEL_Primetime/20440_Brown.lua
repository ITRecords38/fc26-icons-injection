-- UEL Primetime Archie Brown (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 262968
-- Card UID : 20440
-- Fictive Player ID : 46010
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46010
local real_playerid = 262968
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "190",
    weight = "86",
    preferredfoot = "2",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "94",
    stamina = "87",
    agility = "74",
    balance = "70",
    jumping = "87",
    strength = "89",

    shortpassing = "83",
    longpassing = "76",
    vision = "70",
    curve = "70",

    ballcontrol = "82",
    dribbling = "86",
    reactions = "82",
    composure = "77",

    standingtackle = "83",
    slidingtackle = "88",
    interceptions = "80",
    defensiveawareness = "80",
    aggression = "80",

    finishing = "60",
    shotpower = "79",
    longshots = "76",
    volleys = "54",
    penalties = "47",
    headingaccuracy = "67",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "100942336",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Archie",
    surname = "Brown",
    playerjerseyname = "Brown"
})

Log("Created FICTIVE UEL Primetime Archie Brown (18 yo)")
