-- UEL Primetime Ian Maatsen (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 248465
-- Card UID : 20433
-- Fictive Player ID : 46006
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46006
local real_playerid = 248465
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "34",

    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "178",
    weight = "68",
    preferredfoot = "2",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "95",
    sprintspeed = "94",
    stamina = "85",
    agility = "93",
    balance = "93",
    jumping = "81",
    strength = "59",

    shortpassing = "87",
    longpassing = "77",
    vision = "80",
    curve = "80",

    ballcontrol = "88",
    dribbling = "89",
    reactions = "85",
    composure = "84",

    standingtackle = "82",
    slidingtackle = "89",
    interceptions = "86",
    defensiveawareness = "83",
    aggression = "84",

    finishing = "72",
    shotpower = "81",
    longshots = "77",
    volleys = "64",
    penalties = "51",
    headingaccuracy = "66",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "69619712",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Ian",
    surname = "Maatsen",
    playerjerseyname = "Maatsen"
})

Log("Created FICTIVE UEL Primetime Ian Maatsen (18 yo)")
