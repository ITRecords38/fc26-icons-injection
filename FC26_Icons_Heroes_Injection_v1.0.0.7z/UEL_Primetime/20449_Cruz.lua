-- UEL Primetime Igor Jesus Maciel da Cruz (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 79402
-- Card UID : 20449
-- Fictive Player ID : 46017
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46017
local real_playerid = 79402
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "179",
    weight = "75",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "85",
    stamina = "80",
    agility = "78",
    balance = "75",
    jumping = "95",
    strength = "89",

    shortpassing = "83",
    longpassing = "68",
    vision = "80",
    curve = "74",

    ballcontrol = "89",
    dribbling = "85",
    reactions = "90",
    composure = "88",

    standingtackle = "44",
    slidingtackle = "30",
    interceptions = "37",
    defensiveawareness = "40",
    aggression = "83",

    finishing = "88",
    shotpower = "90",
    longshots = "68",
    volleys = "87",
    penalties = "87",
    headingaccuracy = "92",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "557843025",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Igor Jesus Maciel da",
    surname = "Cruz",
    playerjerseyname = "Cruz"
})

Log("Created FICTIVE UEL Primetime Igor Jesus Maciel da Cruz (18 yo)")
