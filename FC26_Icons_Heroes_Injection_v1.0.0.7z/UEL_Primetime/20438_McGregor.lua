-- UEL Primetime Callum McGregor (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 211093
-- Card UID : 20438
-- Fictive Player ID : 46009
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46009
local real_playerid = 211093
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "42",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "178",
    weight = "74",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "82",
    stamina = "95",
    agility = "87",
    balance = "90",
    jumping = "78",
    strength = "80",

    shortpassing = "90",
    longpassing = "86",
    vision = "86",
    curve = "82",

    ballcontrol = "89",
    dribbling = "84",
    reactions = "87",
    composure = "89",

    standingtackle = "82",
    slidingtackle = "80",
    interceptions = "80",
    defensiveawareness = "83",
    aggression = "88",

    finishing = "81",
    shotpower = "86",
    longshots = "86",
    volleys = "82",
    penalties = "72",
    headingaccuracy = "60",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "83953156",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Callum",
    surname = "McGregor",
    playerjerseyname = "McGregor"
})

Log("Created FICTIVE UEL Primetime Callum McGregor (18 yo)")
