-- UEL Primetime Kouadio Manu Koné (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 250723
-- Card UID : 20435
-- Fictive Player ID : 46007
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46007
local real_playerid = 250723
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "185",
    weight = "80",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "80",
    stamina = "86",
    agility = "84",
    balance = "80",
    jumping = "87",
    strength = "86",

    shortpassing = "87",
    longpassing = "83",
    vision = "82",
    curve = "77",

    ballcontrol = "89",
    dribbling = "89",
    reactions = "86",
    composure = "81",

    standingtackle = "90",
    slidingtackle = "81",
    interceptions = "86",
    defensiveawareness = "78",
    aggression = "86",

    finishing = "80",
    shotpower = "93",
    longshots = "83",
    volleys = "61",
    penalties = "60",
    headingaccuracy = "78",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "68223492",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Kouadio Manu",
    surname = "Koné",
    playerjerseyname = "Koné"
})

Log("Created FICTIVE UEL Primetime Kouadio Manu Koné (18 yo)")
