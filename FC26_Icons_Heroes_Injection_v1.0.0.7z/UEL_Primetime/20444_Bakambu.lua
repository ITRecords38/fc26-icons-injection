-- UEL Primetime Cédric Bakambu (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 198951
-- Card UID : 20444
-- Fictive Player ID : 46013
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46013
local real_playerid = 198951
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "110",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "182",
    weight = "73",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "88",
    sprintspeed = "88",
    stamina = "77",
    agility = "86",
    balance = "80",
    jumping = "93",
    strength = "80",

    shortpassing = "80",
    longpassing = "69",
    vision = "75",
    curve = "75",

    ballcontrol = "83",
    dribbling = "85",
    reactions = "81",
    composure = "80",

    standingtackle = "41",
    slidingtackle = "35",
    interceptions = "52",
    defensiveawareness = "43",
    aggression = "72",

    finishing = "87",
    shotpower = "91",
    longshots = "69",
    volleys = "86",
    penalties = "87",
    headingaccuracy = "93",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "577765381",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Cédric",
    surname = "Bakambu",
    playerjerseyname = "Bakambu"
})

Log("Created FICTIVE UEL Primetime Cédric Bakambu (18 yo)")
