-- UWCL Primetime Heroes Simone Laudehr (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 226307
-- Card UID : 20402
-- Fictive Player ID : 46004
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46004
local real_playerid = 226307
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "60",
    preferredfoot = "1",

    overallrating = "90",
    potential = "90",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "87",
    stamina = "93",
    agility = "86",
    balance = "86",
    jumping = "90",
    strength = "74",

    shortpassing = "92",
    longpassing = "87",
    vision = "89",
    curve = "71",

    ballcontrol = "92",
    dribbling = "90",
    reactions = "92",
    composure = "87",

    standingtackle = "86",
    slidingtackle = "90",
    interceptions = "87",
    defensiveawareness = "78",
    aggression = "94",

    finishing = "84",
    shotpower = "77",
    longshots = "87",
    volleys = "70",
    penalties = "87",
    headingaccuracy = "88",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "85197313",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Simone",
    surname = "Laudehr",
    playerjerseyname = "Laudehr"
})

Log("Created FICTIVE UWCL Primetime Heroes Simone Laudehr (18 yo)")
