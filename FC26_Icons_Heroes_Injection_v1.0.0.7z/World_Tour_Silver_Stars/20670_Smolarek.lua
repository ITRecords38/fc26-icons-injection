-- World Tour Silver Stars Wlodzimierz Smolarek (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 269603
-- Card UID : 20670
-- Fictive Player ID : 46014
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46014
local real_playerid = 269603
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "37",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "171",
    weight = "70",
    preferredfoot = "2",

    overallrating = "73",
    potential = "73",
    internationalrep = "3",

    acceleration = "81",
    sprintspeed = "80",
    stamina = "66",
    agility = "78",
    balance = "82",
    jumping = "64",
    strength = "69",

    shortpassing = "68",
    longpassing = "64",
    vision = "63",
    curve = "71",

    ballcontrol = "76",
    dribbling = "78",
    reactions = "75",
    composure = "75",

    standingtackle = "29",
    slidingtackle = "25",
    interceptions = "29",
    defensiveawareness = "17",
    aggression = "70",

    finishing = "88",
    shotpower = "81",
    longshots = "64",
    volleys = "83",
    penalties = "84",
    headingaccuracy = "55",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "50331648",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Wlodzimierz",
    surname = "Smolarek",
    playerjerseyname = "Smolarek"
})

Log("Created FICTIVE World Tour Silver Stars Wlodzimierz Smolarek (18 yo)")
