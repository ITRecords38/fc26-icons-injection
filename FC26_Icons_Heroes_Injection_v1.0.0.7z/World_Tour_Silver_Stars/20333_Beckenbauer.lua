-- World Tour Silver Stars Franz Beckenbauer (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 168473
-- Card UID : 20333
-- Fictive Player ID : 46013
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46013
local real_playerid = 168473
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "181",
    weight = "75",
    preferredfoot = "1",

    overallrating = "71",
    potential = "71",
    internationalrep = "3",

    acceleration = "71",
    sprintspeed = "70",
    stamina = "73",
    agility = "61",
    balance = "60",
    jumping = "82",
    strength = "70",

    shortpassing = "81",
    longpassing = "82",
    vision = "76",
    curve = "66",

    ballcontrol = "70",
    dribbling = "60",
    reactions = "70",
    composure = "68",

    standingtackle = "78",
    slidingtackle = "77",
    interceptions = "83",
    defensiveawareness = "82",
    aggression = "63",

    finishing = "50",
    shotpower = "53",
    longshots = "82",
    volleys = "48",
    penalties = "47",
    headingaccuracy = "76",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "68354304",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Franz",
    surname = "Beckenbauer",
    playerjerseyname = "Beckenbauer"
})

Log("Created FICTIVE World Tour Silver Stars Franz Beckenbauer (18 yo)")
