-- World Tour Silver Stars Roberto Baggio (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 1114
-- Card UID : 21490
-- Fictive Player ID : 46025
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46025
local real_playerid = 1114
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "73",
    preferredfoot = "1",

    overallrating = "73",
    potential = "73",
    internationalrep = "3",

    acceleration = "75",
    sprintspeed = "71",
    stamina = "80",
    agility = "82",
    balance = "80",
    jumping = "58",
    strength = "54",

    shortpassing = "80",
    longpassing = "75",
    vision = "80",
    curve = "79",

    ballcontrol = "88",
    dribbling = "86",
    reactions = "81",
    composure = "78",

    standingtackle = "27",
    slidingtackle = "26",
    interceptions = "29",
    defensiveawareness = "29",
    aggression = "35",

    finishing = "77",
    shotpower = "64",
    longshots = "75",
    volleys = "74",
    penalties = "75",
    headingaccuracy = "60",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "4197385",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Roberto",
    surname = "Baggio",
    playerjerseyname = "Baggio"
})

Log("Created FICTIVE World Tour Silver Stars Roberto Baggio (18 yo)")
