-- World Tour Silver Stars Kenny Dalglish (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 247699
-- Card UID : 20675
-- Fictive Player ID : 46017
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46017
local real_playerid = 247699
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "42",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "173",
    weight = "73",
    preferredfoot = "1",

    overallrating = "71",
    potential = "71",
    internationalrep = "3",

    acceleration = "77",
    sprintspeed = "76",
    stamina = "66",
    agility = "73",
    balance = "73",
    jumping = "61",
    strength = "52",

    shortpassing = "74",
    longpassing = "48",
    vision = "66",
    curve = "71",

    ballcontrol = "72",
    dribbling = "70",
    reactions = "74",
    composure = "73",

    standingtackle = "30",
    slidingtackle = "26",
    interceptions = "23",
    defensiveawareness = "26",
    aggression = "54",

    finishing = "85",
    shotpower = "81",
    longshots = "48",
    volleys = "84",
    penalties = "82",
    headingaccuracy = "62",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "34603073",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Kenny",
    surname = "Dalglish",
    playerjerseyname = "Dalglish"
})

Log("Created FICTIVE World Tour Silver Stars Kenny Dalglish (18 yo)")
