-- World Tour Silver Stars Franco Baresi (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 166906
-- Card UID : 20677
-- Fictive Player ID : 46018
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46018
local real_playerid = 166906
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "176",
    weight = "70",
    preferredfoot = "1",

    overallrating = "74",
    potential = "74",
    internationalrep = "3",

    acceleration = "66",
    sprintspeed = "74",
    stamina = "76",
    agility = "66",
    balance = "68",
    jumping = "76",
    strength = "70",

    shortpassing = "84",
    longpassing = "82",
    vision = "67",
    curve = "55",

    ballcontrol = "76",
    dribbling = "50",
    reactions = "84",
    composure = "76",

    standingtackle = "86",
    slidingtackle = "85",
    interceptions = "86",
    defensiveawareness = "86",
    aggression = "76",

    finishing = "28",
    shotpower = "33",
    longshots = "82",
    volleys = "31",
    penalties = "39",
    headingaccuracy = "80",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "279552",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Franco",
    surname = "Baresi",
    playerjerseyname = "Baresi"
})

Log("Created FICTIVE World Tour Silver Stars Franco Baresi (18 yo)")
