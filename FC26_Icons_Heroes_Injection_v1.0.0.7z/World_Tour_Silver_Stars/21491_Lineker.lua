-- World Tour Silver Stars Gary Lineker (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 214267
-- Card UID : 21491
-- Fictive Player ID : 46026
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46026
local real_playerid = 214267
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "177",
    weight = "74",
    preferredfoot = "1",

    overallrating = "73",
    potential = "73",
    internationalrep = "3",

    acceleration = "76",
    sprintspeed = "73",
    stamina = "80",
    agility = "75",
    balance = "70",
    jumping = "72",
    strength = "74",

    shortpassing = "80",
    longpassing = "67",
    vision = "69",
    curve = "70",

    ballcontrol = "74",
    dribbling = "74",
    reactions = "77",
    composure = "77",

    standingtackle = "29",
    slidingtackle = "27",
    interceptions = "35",
    defensiveawareness = "24",
    aggression = "52",

    finishing = "88",
    shotpower = "84",
    longshots = "67",
    volleys = "86",
    penalties = "90",
    headingaccuracy = "82",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "33554514",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Gary",
    surname = "Lineker",
    playerjerseyname = "Lineker"
})

Log("Created FICTIVE World Tour Silver Stars Gary Lineker (18 yo)")
