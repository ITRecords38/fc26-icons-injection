-- World Tour Silver Stars Sócrates Vieira de Oliveira (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 190046
-- Card UID : 20674
-- Fictive Player ID : 46016
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46016
local real_playerid = 190046
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "192",
    weight = "79",
    preferredfoot = "1",

    overallrating = "72",
    potential = "72",
    internationalrep = "3",

    acceleration = "73",
    sprintspeed = "72",
    stamina = "80",
    agility = "67",
    balance = "52",
    jumping = "60",
    strength = "72",

    shortpassing = "84",
    longpassing = "85",
    vision = "88",
    curve = "83",

    ballcontrol = "75",
    dribbling = "74",
    reactions = "70",
    composure = "78",

    standingtackle = "42",
    slidingtackle = "37",
    interceptions = "26",
    defensiveawareness = "23",
    aggression = "67",

    finishing = "75",
    shotpower = "80",
    longshots = "85",
    volleys = "79",
    penalties = "77",
    headingaccuracy = "70",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1049668",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Sócrates Vieira de",
    surname = "Oliveira",
    playerjerseyname = "Oliveira"
})

Log("Created FICTIVE World Tour Silver Stars Sócrates Vieira de Oliveira (18 yo)")
