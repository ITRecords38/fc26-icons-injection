-- Heroes Marek Hamšík (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 171877
-- Card UID : 18849
-- Fictive Player ID : 46039
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46039
local real_playerid = 171877
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "43",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "183",
    weight = "73",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "84",
    stamina = "91",
    agility = "78",
    balance = "84",
    jumping = "80",
    strength = "81",

    shortpassing = "91",
    longpassing = "89",
    vision = "86",
    curve = "81",

    ballcontrol = "88",
    dribbling = "87",
    reactions = "86",
    composure = "87",

    standingtackle = "76",
    slidingtackle = "71",
    interceptions = "78",
    defensiveawareness = "72",
    aggression = "78",

    finishing = "85",
    shotpower = "90",
    longshots = "89",
    volleys = "82",
    penalties = "83",
    headingaccuracy = "78",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "83887108",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Marek",
    surname = "Hamšík",
    playerjerseyname = "Hamšík"
})

Log("Created FICTIVE Heroes Marek Hamšík (18 yo)")
