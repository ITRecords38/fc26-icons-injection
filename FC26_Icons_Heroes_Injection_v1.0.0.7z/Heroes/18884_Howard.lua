-- Heroes Tim Howard (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 16254
-- Card UID : 18884
-- Fictive Player ID : 46073
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46073
local real_playerid = 16254
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "95",

    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "191",
    weight = "85",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "56",
    sprintspeed = "52",
    stamina = "25",
    agility = "61",
    balance = "60",
    jumping = "77",
    strength = "78",

    shortpassing = "35",
    longpassing = "43",
    vision = "60",
    curve = "18",

    ballcontrol = "31",
    dribbling = "18",
    reactions = "83",
    composure = "64",

    standingtackle = "15",
    slidingtackle = "16",
    interceptions = "25",
    defensiveawareness = "23",
    aggression = "44",

    finishing = "20",
    shotpower = "65",
    longshots = "43",
    volleys = "13",
    penalties = "32",
    headingaccuracy = "17",

    skillmoves = "0",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "0",
    trait2 = "6",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Tim",
    surname = "Howard",
    playerjerseyname = "Howard"
})

Log("Created FICTIVE Heroes Tim Howard (18 yo)")
