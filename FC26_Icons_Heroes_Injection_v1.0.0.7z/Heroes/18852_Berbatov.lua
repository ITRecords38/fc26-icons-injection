-- Heroes Dimitar Berbatov (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 30110
-- Card UID : 18852
-- Fictive Player ID : 46042
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46042
local real_playerid = 30110
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "9",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "189",
    weight = "75",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "76",
    sprintspeed = "83",
    stamina = "76",
    agility = "84",
    balance = "80",
    jumping = "68",
    strength = "80",

    shortpassing = "84",
    longpassing = "76",
    vision = "85",
    curve = "83",

    ballcontrol = "93",
    dribbling = "85",
    reactions = "85",
    composure = "91",

    standingtackle = "27",
    slidingtackle = "22",
    interceptions = "26",
    defensiveawareness = "34",
    aggression = "58",

    finishing = "88",
    shotpower = "85",
    longshots = "76",
    volleys = "87",
    penalties = "88",
    headingaccuracy = "83",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "8352",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Dimitar",
    surname = "Berbatov",
    playerjerseyname = "Berbatov"
})

Log("Created FICTIVE Heroes Dimitar Berbatov (18 yo)")
