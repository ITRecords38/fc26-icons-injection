-- Heroes Paulo Jorge dos Santos Futre (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 214101
-- Card UID : 18828
-- Fictive Player ID : 46018
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46018
local real_playerid = 214101
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "38",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "74",
    preferredfoot = "2",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "95",
    sprintspeed = "92",
    stamina = "72",
    agility = "93",
    balance = "92",
    jumping = "58",
    strength = "56",

    shortpassing = "81",
    longpassing = "74",
    vision = "78",
    curve = "78",

    ballcontrol = "92",
    dribbling = "95",
    reactions = "86",
    composure = "92",

    standingtackle = "33",
    slidingtackle = "29",
    interceptions = "31",
    defensiveawareness = "35",
    aggression = "45",

    finishing = "81",
    shotpower = "77",
    longshots = "74",
    volleys = "81",
    penalties = "93",
    headingaccuracy = "72",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "37757184",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Paulo Jorge dos Santos",
    surname = "Futre",
    playerjerseyname = "Futre"
})

Log("Created FICTIVE Heroes Paulo Jorge dos Santos Futre (18 yo)")
