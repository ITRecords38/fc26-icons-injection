-- Heroes Yaya Touré (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 20289
-- Card UID : 18841
-- Fictive Player ID : 46031
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46031
local real_playerid = 20289
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "108",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "188",
    weight = "90",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "76",
    sprintspeed = "80",
    stamina = "94",
    agility = "76",
    balance = "69",
    jumping = "71",
    strength = "92",

    shortpassing = "91",
    longpassing = "86",
    vision = "90",
    curve = "85",

    ballcontrol = "89",
    dribbling = "83",
    reactions = "86",
    composure = "85",

    standingtackle = "86",
    slidingtackle = "83",
    interceptions = "78",
    defensiveawareness = "77",
    aggression = "81",

    finishing = "80",
    shotpower = "90",
    longshots = "86",
    volleys = "73",
    penalties = "86",
    headingaccuracy = "71",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "822214661",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Yaya",
    surname = "Touré",
    playerjerseyname = "Touré"
})

Log("Created FICTIVE Heroes Yaya Touré (18 yo)")
