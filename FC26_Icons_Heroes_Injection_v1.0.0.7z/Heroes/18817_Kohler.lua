-- Heroes Jürgen Kohler (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 261593
-- Card UID : 18817
-- Fictive Player ID : 46007
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46007
local real_playerid = 261593
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "186",
    weight = "84",
    preferredfoot = "1",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "67",
    sprintspeed = "75",
    stamina = "86",
    agility = "64",
    balance = "71",
    jumping = "89",
    strength = "90",

    shortpassing = "74",
    longpassing = "70",
    vision = "52",
    curve = "47",

    ballcontrol = "64",
    dribbling = "55",
    reactions = "90",
    composure = "80",

    standingtackle = "91",
    slidingtackle = "93",
    interceptions = "87",
    defensiveawareness = "93",
    aggression = "94",

    finishing = "47",
    shotpower = "66",
    longshots = "70",
    volleys = "53",
    penalties = "55",
    headingaccuracy = "88",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268845072",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Jürgen",
    surname = "Kohler",
    playerjerseyname = "Kohler"
})

Log("Created FICTIVE Heroes Jürgen Kohler (18 yo)")
