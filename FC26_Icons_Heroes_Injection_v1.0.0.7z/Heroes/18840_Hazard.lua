-- Heroes Eden Hazard (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 183277
-- Card UID : 18840
-- Fictive Player ID : 46030
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46030
local real_playerid = 183277
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "7",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "74",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "93",
    sprintspeed = "89",
    stamina = "83",
    agility = "92",
    balance = "91",
    jumping = "64",
    strength = "68",

    shortpassing = "86",
    longpassing = "83",
    vision = "86",
    curve = "84",

    ballcontrol = "90",
    dribbling = "93",
    reactions = "87",
    composure = "89",

    standingtackle = "31",
    slidingtackle = "24",
    interceptions = "46",
    defensiveawareness = "32",
    aggression = "50",

    finishing = "85",
    shotpower = "82",
    longshots = "83",
    volleys = "78",
    penalties = "88",
    headingaccuracy = "60",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "46139393",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Eden",
    surname = "Hazard",
    playerjerseyname = "Hazard"
})

Log("Created FICTIVE Heroes Eden Hazard (18 yo)")
