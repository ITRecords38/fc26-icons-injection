-- Heroes Abedi Ayew (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 167425
-- Card UID : 18820
-- Fictive Player ID : 46010
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46010
local real_playerid = 167425
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "117",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "67",
    preferredfoot = "2",

    overallrating = "89",
    potential = "89",
    internationalrep = "3",

    acceleration = "92",
    sprintspeed = "91",
    stamina = "83",
    agility = "95",
    balance = "90",
    jumping = "75",
    strength = "65",

    shortpassing = "88",
    longpassing = "78",
    vision = "90",
    curve = "88",

    ballcontrol = "92",
    dribbling = "91",
    reactions = "91",
    composure = "82",

    standingtackle = "44",
    slidingtackle = "41",
    interceptions = "43",
    defensiveawareness = "47",
    aggression = "47",

    finishing = "80",
    shotpower = "83",
    longshots = "78",
    volleys = "85",
    penalties = "86",
    headingaccuracy = "79",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "33562912",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Abedi",
    surname = "Ayew",
    playerjerseyname = "Ayew"
})

Log("Created FICTIVE Heroes Abedi Ayew (18 yo)")
