-- Heroes Steve McManaman (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 273812
-- Card UID : 18846
-- Fictive Player ID : 46036
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46036
local real_playerid = 273812
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "12",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "183",
    weight = "72",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "87",
    sprintspeed = "90",
    stamina = "91",
    agility = "82",
    balance = "70",
    jumping = "72",
    strength = "75",

    shortpassing = "86",
    longpassing = "81",
    vision = "87",
    curve = "83",

    ballcontrol = "87",
    dribbling = "91",
    reactions = "85",
    composure = "83",

    standingtackle = "51",
    slidingtackle = "42",
    interceptions = "40",
    defensiveawareness = "38",
    aggression = "68",

    finishing = "75",
    shotpower = "78",
    longshots = "81",
    volleys = "81",
    penalties = "74",
    headingaccuracy = "66",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "5242882",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Steve",
    surname = "McManaman",
    playerjerseyname = "McManaman"
})

Log("Created FICTIVE Heroes Steve McManaman (18 yo)")
