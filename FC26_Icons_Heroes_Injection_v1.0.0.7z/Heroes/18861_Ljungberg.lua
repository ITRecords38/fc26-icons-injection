-- Heroes Freddie Ljungberg (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 6975
-- Card UID : 18861
-- Fictive Player ID : 46051
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46051
local real_playerid = 6975
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "46",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "73",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "86",
    stamina = "86",
    agility = "84",
    balance = "80",
    jumping = "68",
    strength = "74",

    shortpassing = "84",
    longpassing = "75",
    vision = "83",
    curve = "83",

    ballcontrol = "86",
    dribbling = "88",
    reactions = "86",
    composure = "79",

    standingtackle = "42",
    slidingtackle = "36",
    interceptions = "44",
    defensiveawareness = "48",
    aggression = "73",

    finishing = "86",
    shotpower = "79",
    longshots = "75",
    volleys = "70",
    penalties = "71",
    headingaccuracy = "58",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1410",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Freddie",
    surname = "Ljungberg",
    playerjerseyname = "Ljungberg"
})

Log("Created FICTIVE Heroes Freddie Ljungberg (18 yo)")
