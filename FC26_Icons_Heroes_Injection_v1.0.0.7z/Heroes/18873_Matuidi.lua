-- Heroes Blaise Matuidi (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 170890
-- Card UID : 18873
-- Fictive Player ID : 46062
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46062
local real_playerid = 170890
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "75",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "82",
    stamina = "94",
    agility = "75",
    balance = "78",
    jumping = "80",
    strength = "82",

    shortpassing = "85",
    longpassing = "78",
    vision = "81",
    curve = "75",

    ballcontrol = "80",
    dribbling = "75",
    reactions = "84",
    composure = "81",

    standingtackle = "87",
    slidingtackle = "81",
    interceptions = "91",
    defensiveawareness = "83",
    aggression = "84",

    finishing = "67",
    shotpower = "83",
    longshots = "78",
    volleys = "71",
    penalties = "59",
    headingaccuracy = "68",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "117637120",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Blaise",
    surname = "Matuidi",
    playerjerseyname = "Matuidi"
})

Log("Created FICTIVE Heroes Blaise Matuidi (18 yo)")
