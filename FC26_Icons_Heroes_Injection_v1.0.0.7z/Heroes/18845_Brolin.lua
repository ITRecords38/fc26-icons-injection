-- Heroes Tomas Brolin (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 266695
-- Card UID : 18845
-- Fictive Player ID : 46035
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46035
local real_playerid = 266695
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "46",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "176",
    weight = "73",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "86",
    stamina = "79",
    agility = "87",
    balance = "85",
    jumping = "83",
    strength = "64",

    shortpassing = "86",
    longpassing = "79",
    vision = "86",
    curve = "82",

    ballcontrol = "91",
    dribbling = "92",
    reactions = "89",
    composure = "84",

    standingtackle = "56",
    slidingtackle = "60",
    interceptions = "53",
    defensiveawareness = "58",
    aggression = "67",

    finishing = "87",
    shotpower = "91",
    longshots = "79",
    volleys = "84",
    penalties = "86",
    headingaccuracy = "83",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "4194564",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Tomas",
    surname = "Brolin",
    playerjerseyname = "Brolin"
})

Log("Created FICTIVE Heroes Tomas Brolin (18 yo)")
