-- Heroes Daniele De Rossi (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 53302
-- Card UID : 20568
-- Fictive Player ID : 46081
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46081
local real_playerid = 53302
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "184",
    weight = "83",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "79",
    sprintspeed = "78",
    stamina = "89",
    agility = "74",
    balance = "75",
    jumping = "85",
    strength = "84",

    shortpassing = "86",
    longpassing = "83",
    vision = "78",
    curve = "74",

    ballcontrol = "84",
    dribbling = "76",
    reactions = "86",
    composure = "84",

    standingtackle = "88",
    slidingtackle = "89",
    interceptions = "88",
    defensiveawareness = "87",
    aggression = "90",

    finishing = "78",
    shotpower = "89",
    longshots = "83",
    volleys = "71",
    penalties = "80",
    headingaccuracy = "86",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "67731472",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Daniele De",
    surname = "Rossi",
    playerjerseyname = "Rossi"
})

Log("Created FICTIVE Heroes Daniele De Rossi (18 yo)")
