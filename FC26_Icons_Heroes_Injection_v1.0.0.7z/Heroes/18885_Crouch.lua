-- Heroes Peter Crouch (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 51257
-- Card UID : 18885
-- Fictive Player ID : 46074
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46074
local real_playerid = 51257
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "201",
    weight = "75",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "71",
    sprintspeed = "76",
    stamina = "79",
    agility = "68",
    balance = "54",
    jumping = "78",
    strength = "82",

    shortpassing = "83",
    longpassing = "74",
    vision = "78",
    curve = "65",

    ballcontrol = "84",
    dribbling = "77",
    reactions = "85",
    composure = "87",

    standingtackle = "46",
    slidingtackle = "41",
    interceptions = "43",
    defensiveawareness = "52",
    aggression = "75",

    finishing = "89",
    shotpower = "84",
    longshots = "74",
    volleys = "89",
    penalties = "88",
    headingaccuracy = "94",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1048656",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Peter",
    surname = "Crouch",
    playerjerseyname = "Crouch"
})

Log("Created FICTIVE Heroes Peter Crouch (18 yo)")
