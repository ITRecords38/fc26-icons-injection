-- POTM Liga F Claudia Pina Medina (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 262531
-- Card UID : 21172
-- Fictive Player ID : 46006
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46006
local real_playerid = 262531
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "160",
    weight = "68",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "80",
    sprintspeed = "80",
    stamina = "78",
    agility = "85",
    balance = "86",
    jumping = "73",
    strength = "71",

    shortpassing = "88",
    longpassing = "77",
    vision = "86",
    curve = "83",

    ballcontrol = "89",
    dribbling = "89",
    reactions = "86",
    composure = "82",

    standingtackle = "57",
    slidingtackle = "53",
    interceptions = "39",
    defensiveawareness = "33",
    aggression = "71",

    finishing = "88",
    shotpower = "86",
    longshots = "77",
    volleys = "89",
    penalties = "65",
    headingaccuracy = "72",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1051080",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Claudia Pina",
    surname = "Medina",
    playerjerseyname = "Medina"
})

Log("Created FICTIVE POTM Liga F Claudia Pina Medina (18 yo)")
