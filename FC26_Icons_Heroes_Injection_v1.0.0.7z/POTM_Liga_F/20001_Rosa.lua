-- POTM Liga F Luany Vitória da Silva Rosa (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 274780
-- Card UID : 20001
-- Fictive Player ID : 46004
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46004
local real_playerid = 274780
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "12",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "164",
    weight = "54",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "90",
    stamina = "91",
    agility = "85",
    balance = "77",
    jumping = "83",
    strength = "78",

    shortpassing = "83",
    longpassing = "70",
    vision = "84",
    curve = "65",

    ballcontrol = "86",
    dribbling = "86",
    reactions = "77",
    composure = "82",

    standingtackle = "41",
    slidingtackle = "39",
    interceptions = "56",
    defensiveawareness = "46",
    aggression = "77",

    finishing = "88",
    shotpower = "84",
    longshots = "70",
    volleys = "72",
    penalties = "68",
    headingaccuracy = "71",

    skillmoves = "2",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "17833986",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Luany Vitória da Silva",
    surname = "Rosa",
    playerjerseyname = "Rosa"
})

Log("Created FICTIVE POTM Liga F Luany Vitória da Silva Rosa (18 yo)")
