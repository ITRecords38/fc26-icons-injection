-- Gold Rare Ashley Lawrence (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 227392
-- Card UID : 17319
-- Fictive Player ID : 46417
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46417
local real_playerid = 227392
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "70",

    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "164",
    weight = "60",
    preferredfoot = "1",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "80",
    sprintspeed = "83",
    stamina = "80",
    agility = "84",
    balance = "87",
    jumping = "82",
    strength = "72",

    shortpassing = "84",
    longpassing = "81",
    vision = "82",
    curve = "78",

    ballcontrol = "78",
    dribbling = "78",
    reactions = "82",
    composure = "83",

    standingtackle = "84",
    slidingtackle = "81",
    interceptions = "80",
    defensiveawareness = "83",
    aggression = "80",

    finishing = "58",
    shotpower = "79",
    longshots = "81",
    volleys = "66",
    penalties = "67",
    headingaccuracy = "73",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "34623488",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Ashley",
    surname = "Lawrence",
    playerjerseyname = "Lawrence"
})

Log("Created FICTIVE Gold Rare Ashley Lawrence (18 yo)")
