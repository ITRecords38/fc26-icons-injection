-- Gold Rare Sandy Baltimore (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 261733
-- Card UID : 531
-- Fictive Player ID : 46198
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46198
local real_playerid = 261733
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "156",
    weight = "62",
    preferredfoot = "2",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "91",
    sprintspeed = "83",
    stamina = "74",
    agility = "81",
    balance = "91",
    jumping = "68",
    strength = "71",

    shortpassing = "85",
    longpassing = "80",
    vision = "85",
    curve = "90",

    ballcontrol = "88",
    dribbling = "87",
    reactions = "72",
    composure = "80",

    standingtackle = "77",
    slidingtackle = "75",
    interceptions = "75",
    defensiveawareness = "73",
    aggression = "58",

    finishing = "74",
    shotpower = "73",
    longshots = "80",
    volleys = "62",
    penalties = "74",
    headingaccuracy = "46",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "34615552",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Sandy",
    surname = "Baltimore",
    playerjerseyname = "Baltimore"
})

Log("Created FICTIVE Gold Rare Sandy Baltimore (18 yo)")
