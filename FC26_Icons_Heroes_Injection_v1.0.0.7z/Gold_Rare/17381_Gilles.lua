-- Gold Rare Vanessa Gilles (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 247513
-- Card UID : 17381
-- Fictive Player ID : 46479
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46479
local real_playerid = 247513
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "70",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "58",
    preferredfoot = "1",

    overallrating = "83",
    potential = "83",
    internationalrep = "3",

    acceleration = "50",
    sprintspeed = "64",
    stamina = "65",
    agility = "44",
    balance = "67",
    jumping = "79",
    strength = "89",

    shortpassing = "79",
    longpassing = "74",
    vision = "32",
    curve = "38",

    ballcontrol = "66",
    dribbling = "45",
    reactions = "76",
    composure = "64",

    standingtackle = "89",
    slidingtackle = "81",
    interceptions = "82",
    defensiveawareness = "87",
    aggression = "79",

    finishing = "27",
    shotpower = "68",
    longshots = "74",
    volleys = "33",
    penalties = "38",
    headingaccuracy = "89",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "558096",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Vanessa",
    surname = "Gilles",
    playerjerseyname = "Gilles"
})

Log("Created FICTIVE Gold Rare Vanessa Gilles (18 yo)")
