-- Gold Rare Alexandru Mitriță (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 229804
-- Card UID : 6424
-- Fictive Player ID : 46393
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46393
local real_playerid = 229804
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "39",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "171",
    weight = "65",
    preferredfoot = "1",

    overallrating = "75",
    potential = "75",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "83",
    stamina = "82",
    agility = "92",
    balance = "93",
    jumping = "62",
    strength = "58",

    shortpassing = "70",
    longpassing = "63",
    vision = "71",
    curve = "75",

    ballcontrol = "79",
    dribbling = "82",
    reactions = "68",
    composure = "71",

    standingtackle = "25",
    slidingtackle = "27",
    interceptions = "22",
    defensiveawareness = "32",
    aggression = "57",

    finishing = "75",
    shotpower = "74",
    longshots = "63",
    volleys = "65",
    penalties = "61",
    headingaccuracy = "31",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "35651656",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Alexandru",
    surname = "Mitriță",
    playerjerseyname = "Mitriță"
})

Log("Created FICTIVE Gold Rare Alexandru Mitriță (18 yo)")
