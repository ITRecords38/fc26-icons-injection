-- Gold Rare Khvicha Kvaratskhelia (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 247635
-- Card UID : 215
-- Fictive Player ID : 46078
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46078
local real_playerid = 247635
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "20",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "183",
    weight = "70",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "86",
    stamina = "83",
    agility = "86",
    balance = "84",
    jumping = "87",
    strength = "76",

    shortpassing = "87",
    longpassing = "78",
    vision = "85",
    curve = "86",

    ballcontrol = "88",
    dribbling = "89",
    reactions = "84",
    composure = "84",

    standingtackle = "62",
    slidingtackle = "52",
    interceptions = "58",
    defensiveawareness = "53",
    aggression = "73",

    finishing = "81",
    shotpower = "78",
    longshots = "78",
    volleys = "64",
    penalties = "70",
    headingaccuracy = "62",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "9437569",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Khvicha",
    surname = "Kvaratskhelia",
    playerjerseyname = "Kvaratskhelia"
})

Log("Created FICTIVE Gold Rare Khvicha Kvaratskhelia (18 yo)")
