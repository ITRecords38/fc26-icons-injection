-- Gold Rare Fabricio Bustos (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 236441
-- Card UID : 18432
-- Fictive Player ID : 46823
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46823
local real_playerid = 236441
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "167",
    weight = "70",
    preferredfoot = "1",

    overallrating = "76",
    potential = "76",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "82",
    stamina = "83",
    agility = "82",
    balance = "82",
    jumping = "79",
    strength = "67",

    shortpassing = "74",
    longpassing = "73",
    vision = "72",
    curve = "76",

    ballcontrol = "78",
    dribbling = "79",
    reactions = "74",
    composure = "76",

    standingtackle = "72",
    slidingtackle = "74",
    interceptions = "71",
    defensiveawareness = "63",
    aggression = "78",

    finishing = "65",
    shotpower = "74",
    longshots = "73",
    volleys = "41",
    penalties = "48",
    headingaccuracy = "60",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "2097152",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Fabricio",
    surname = "Bustos",
    playerjerseyname = "Bustos"
})

Log("Created FICTIVE Gold Rare Fabricio Bustos (18 yo)")
