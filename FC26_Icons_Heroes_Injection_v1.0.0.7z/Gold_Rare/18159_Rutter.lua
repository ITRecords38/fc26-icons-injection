-- Gold Rare Georginio Rutter (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 245637
-- Card UID : 18159
-- Fictive Player ID : 46791
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46791
local real_playerid = 245637
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "182",
    weight = "83",
    preferredfoot = "2",

    overallrating = "77",
    potential = "77",
    internationalrep = "3",

    acceleration = "76",
    sprintspeed = "77",
    stamina = "79",
    agility = "77",
    balance = "79",
    jumping = "85",
    strength = "76",

    shortpassing = "76",
    longpassing = "74",
    vision = "77",
    curve = "75",

    ballcontrol = "81",
    dribbling = "80",
    reactions = "77",
    composure = "77",

    standingtackle = "62",
    slidingtackle = "50",
    interceptions = "56",
    defensiveawareness = "58",
    aggression = "59",

    finishing = "76",
    shotpower = "76",
    longshots = "74",
    volleys = "71",
    penalties = "70",
    headingaccuracy = "73",

    skillmoves = "4",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "545259776",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Georginio",
    surname = "Rutter",
    playerjerseyname = "Rutter"
})

Log("Created FICTIVE Gold Rare Georginio Rutter (18 yo)")
