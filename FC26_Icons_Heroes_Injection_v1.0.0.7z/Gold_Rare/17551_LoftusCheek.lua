-- Gold Rare Ruben Loftus-Cheek (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 213666
-- Card UID : 17551
-- Fictive Player ID : 46606
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46606
local real_playerid = 213666
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "191",
    weight = "88",
    preferredfoot = "1",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "78",
    sprintspeed = "84",
    stamina = "72",
    agility = "75",
    balance = "60",
    jumping = "94",
    strength = "85",

    shortpassing = "84",
    longpassing = "80",
    vision = "79",
    curve = "70",

    ballcontrol = "83",
    dribbling = "81",
    reactions = "79",
    composure = "82",

    standingtackle = "76",
    slidingtackle = "70",
    interceptions = "76",
    defensiveawareness = "75",
    aggression = "75",

    finishing = "76",
    shotpower = "82",
    longshots = "80",
    volleys = "60",
    penalties = "56",
    headingaccuracy = "85",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "554172416",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Ruben",
    surname = "Loftus-Cheek",
    playerjerseyname = "Loftus-Cheek"
})

Log("Created FICTIVE Gold Rare Ruben Loftus-Cheek (18 yo)")
