-- Gold Rare Jule Brand (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 261740
-- Card UID : 17349
-- Fictive Player ID : 46447
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46447
local real_playerid = 261740
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "177",
    weight = "62",
    preferredfoot = "1",

    overallrating = "83",
    potential = "83",
    internationalrep = "3",

    acceleration = "92",
    sprintspeed = "91",
    stamina = "80",
    agility = "85",
    balance = "74",
    jumping = "77",
    strength = "73",

    shortpassing = "83",
    longpassing = "72",
    vision = "79",
    curve = "68",

    ballcontrol = "85",
    dribbling = "81",
    reactions = "81",
    composure = "76",

    standingtackle = "59",
    slidingtackle = "55",
    interceptions = "50",
    defensiveawareness = "53",
    aggression = "68",

    finishing = "79",
    shotpower = "70",
    longshots = "72",
    volleys = "61",
    penalties = "56",
    headingaccuracy = "68",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "35664256",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Jule",
    surname = "Brand",
    playerjerseyname = "Brand"
})

Log("Created FICTIVE Gold Rare Jule Brand (18 yo)")
