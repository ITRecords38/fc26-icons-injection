-- Gold Rare Rafael da Conceição Leão (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 241721
-- Card UID : 17332
-- Fictive Player ID : 46430
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46430
local real_playerid = 241721
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "38",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "188",
    weight = "81",
    preferredfoot = "1",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "93",
    sprintspeed = "93",
    stamina = "75",
    agility = "84",
    balance = "79",
    jumping = "89",
    strength = "79",

    shortpassing = "83",
    longpassing = "70",
    vision = "81",
    curve = "79",

    ballcontrol = "86",
    dribbling = "87",
    reactions = "83",
    composure = "83",

    standingtackle = "24",
    slidingtackle = "21",
    interceptions = "24",
    defensiveawareness = "22",
    aggression = "60",

    finishing = "82",
    shotpower = "80",
    longshots = "70",
    volleys = "74",
    penalties = "63",
    headingaccuracy = "72",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "44040576",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Rafael da Conceição",
    surname = "Leão",
    playerjerseyname = "Leão"
})

Log("Created FICTIVE Gold Rare Rafael da Conceição Leão (18 yo)")
