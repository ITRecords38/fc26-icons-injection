-- Gold Rare Nicolas Jackson (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 259197
-- Card UID : 17637
-- Fictive Player ID : 46650
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46650
local real_playerid = 259197
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "136",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "78",
    preferredfoot = "1",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "81",
    sprintspeed = "83",
    stamina = "81",
    agility = "72",
    balance = "71",
    jumping = "89",
    strength = "77",

    shortpassing = "77",
    longpassing = "62",
    vision = "73",
    curve = "72",

    ballcontrol = "79",
    dribbling = "81",
    reactions = "80",
    composure = "77",

    standingtackle = "40",
    slidingtackle = "30",
    interceptions = "40",
    defensiveawareness = "30",
    aggression = "70",

    finishing = "81",
    shotpower = "79",
    longshots = "62",
    volleys = "76",
    penalties = "60",
    headingaccuracy = "76",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1048768",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Nicolas",
    surname = "Jackson",
    playerjerseyname = "Jackson"
})

Log("Created FICTIVE Gold Rare Nicolas Jackson (18 yo)")
