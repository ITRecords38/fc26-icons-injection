-- Gold Rare Marc Cucurella Saseta (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 239231
-- Card UID : 384
-- Fictive Player ID : 46166
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46166
local real_playerid = 239231
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "66",
    preferredfoot = "2",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "77",
    sprintspeed = "74",
    stamina = "89",
    agility = "82",
    balance = "83",
    jumping = "86",
    strength = "70",

    shortpassing = "82",
    longpassing = "79",
    vision = "77",
    curve = "79",

    ballcontrol = "80",
    dribbling = "78",
    reactions = "84",
    composure = "79",

    standingtackle = "84",
    slidingtackle = "82",
    interceptions = "82",
    defensiveawareness = "83",
    aggression = "85",

    finishing = "61",
    shotpower = "73",
    longshots = "79",
    volleys = "55",
    penalties = "57",
    headingaccuracy = "72",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "83935232",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Marc Cucurella",
    surname = "Saseta",
    playerjerseyname = "Saseta"
})

Log("Created FICTIVE Gold Rare Marc Cucurella Saseta (18 yo)")
