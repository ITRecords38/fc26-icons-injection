-- Gold Rare António João Tavares Silva (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 270086
-- Card UID : 18078
-- Fictive Player ID : 46781
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46781
local real_playerid = 270086
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "38",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "82",
    preferredfoot = "1",

    overallrating = "78",
    potential = "78",
    internationalrep = "3",

    acceleration = "78",
    sprintspeed = "81",
    stamina = "83",
    agility = "57",
    balance = "58",
    jumping = "83",
    strength = "83",

    shortpassing = "77",
    longpassing = "76",
    vision = "68",
    curve = "36",

    ballcontrol = "73",
    dribbling = "69",
    reactions = "75",
    composure = "77",

    standingtackle = "81",
    slidingtackle = "77",
    interceptions = "74",
    defensiveawareness = "80",
    aggression = "70",

    finishing = "31",
    shotpower = "60",
    longshots = "76",
    volleys = "51",
    penalties = "40",
    headingaccuracy = "76",

    skillmoves = "1",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "33792",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "António João Tavares",
    surname = "Silva",
    playerjerseyname = "Silva"
})

Log("Created FICTIVE Gold Rare António João Tavares Silva (18 yo)")
