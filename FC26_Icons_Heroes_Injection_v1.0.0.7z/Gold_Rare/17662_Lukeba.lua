-- Gold Rare Castello Lukeba (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 262138
-- Card UID : 17662
-- Fictive Player ID : 46662
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46662
local real_playerid = 262138
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "183",
    weight = "84",
    preferredfoot = "2",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "73",
    sprintspeed = "71",
    stamina = "65",
    agility = "70",
    balance = "68",
    jumping = "88",
    strength = "78",

    shortpassing = "76",
    longpassing = "75",
    vision = "72",
    curve = "54",

    ballcontrol = "74",
    dribbling = "73",
    reactions = "79",
    composure = "80",

    standingtackle = "85",
    slidingtackle = "77",
    interceptions = "80",
    defensiveawareness = "80",
    aggression = "78",

    finishing = "41",
    shotpower = "55",
    longshots = "75",
    volleys = "42",
    penalties = "39",
    headingaccuracy = "81",

    skillmoves = "1",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "0",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Castello",
    surname = "Lukeba",
    playerjerseyname = "Lukeba"
})

Log("Created FICTIVE Gold Rare Castello Lukeba (18 yo)")
