-- Gold Rare Lucas Estella Perri (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 230670
-- Card UID : 845
-- Fictive Player ID : 46275
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46275
local real_playerid = 230670
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "197",
    weight = "98",
    preferredfoot = "1",

    overallrating = "81",
    potential = "81",
    internationalrep = "3",

    acceleration = "32",
    sprintspeed = "39",
    stamina = "38",
    agility = "37",
    balance = "27",
    jumping = "69",
    strength = "83",

    shortpassing = "45",
    longpassing = "48",
    vision = "65",
    curve = "22",

    ballcontrol = "14",
    dribbling = "18",
    reactions = "77",
    composure = "44",

    standingtackle = "18",
    slidingtackle = "14",
    interceptions = "25",
    defensiveawareness = "10",
    aggression = "35",

    finishing = "11",
    shotpower = "59",
    longshots = "48",
    volleys = "15",
    penalties = "19",
    headingaccuracy = "13",

    skillmoves = "0",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "0",
    trait2 = "1",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Lucas Estella",
    surname = "Perri",
    playerjerseyname = "Perri"
})

Log("Created FICTIVE Gold Rare Lucas Estella Perri (18 yo)")
