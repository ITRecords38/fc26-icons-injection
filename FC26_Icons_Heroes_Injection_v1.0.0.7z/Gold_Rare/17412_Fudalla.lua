-- Gold Rare Vanessa Fudalla (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 265377
-- Card UID : 17412
-- Fictive Player ID : 46508
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46508
local real_playerid = 265377
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "155",
    weight = "54",
    preferredfoot = "2",

    overallrating = "82",
    potential = "82",
    internationalrep = "3",

    acceleration = "87",
    sprintspeed = "84",
    stamina = "75",
    agility = "71",
    balance = "82",
    jumping = "80",
    strength = "69",

    shortpassing = "79",
    longpassing = "75",
    vision = "83",
    curve = "69",

    ballcontrol = "82",
    dribbling = "79",
    reactions = "83",
    composure = "69",

    standingtackle = "68",
    slidingtackle = "44",
    interceptions = "67",
    defensiveawareness = "33",
    aggression = "67",

    finishing = "85",
    shotpower = "86",
    longshots = "75",
    volleys = "72",
    penalties = "77",
    headingaccuracy = "67",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "12",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Vanessa",
    surname = "Fudalla",
    playerjerseyname = "Fudalla"
})

Log("Created FICTIVE Gold Rare Vanessa Fudalla (18 yo)")
