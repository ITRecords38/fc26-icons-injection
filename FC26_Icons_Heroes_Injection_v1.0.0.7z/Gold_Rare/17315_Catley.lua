-- Gold Rare Steph Catley (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 227119
-- Card UID : 17315
-- Fictive Player ID : 46413
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46413
local real_playerid = 227119
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "195",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "171",
    weight = "60",
    preferredfoot = "2",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "80",
    stamina = "84",
    agility = "82",
    balance = "74",
    jumping = "91",
    strength = "83",

    shortpassing = "87",
    longpassing = "76",
    vision = "69",
    curve = "82",

    ballcontrol = "86",
    dribbling = "75",
    reactions = "85",
    composure = "80",

    standingtackle = "83",
    slidingtackle = "81",
    interceptions = "86",
    defensiveawareness = "87",
    aggression = "78",

    finishing = "70",
    shotpower = "68",
    longshots = "76",
    volleys = "60",
    penalties = "52",
    headingaccuracy = "80",

    skillmoves = "2",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "35655680",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Steph",
    surname = "Catley",
    playerjerseyname = "Catley"
})

Log("Created FICTIVE Gold Rare Steph Catley (18 yo)")
