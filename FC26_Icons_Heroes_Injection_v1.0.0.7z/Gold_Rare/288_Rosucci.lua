-- Gold Rare Martina Rosucci (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 227067
-- Card UID : 288
-- Fictive Player ID : 46134
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46134
local real_playerid = 227067
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "171",
    weight = "61",
    preferredfoot = "1",

    overallrating = "79",
    potential = "79",
    internationalrep = "3",

    acceleration = "69",
    sprintspeed = "72",
    stamina = "78",
    agility = "70",
    balance = "75",
    jumping = "78",
    strength = "73",

    shortpassing = "88",
    longpassing = "80",
    vision = "82",
    curve = "73",

    ballcontrol = "80",
    dribbling = "79",
    reactions = "80",
    composure = "83",

    standingtackle = "79",
    slidingtackle = "78",
    interceptions = "82",
    defensiveawareness = "84",
    aggression = "79",

    finishing = "61",
    shotpower = "75",
    longshots = "80",
    volleys = "70",
    penalties = "62",
    headingaccuracy = "72",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1310720",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Martina",
    surname = "Rosucci",
    playerjerseyname = "Rosucci"
})

Log("Created FICTIVE Gold Rare Martina Rosucci (18 yo)")
