-- Gold Rare Sophia Wilson (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 264012
-- Card UID : 74
-- Fictive Player ID : 46023
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46023
local real_playerid = 264012
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "95",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "164",
    weight = "58",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "91",
    sprintspeed = "92",
    stamina = "85",
    agility = "85",
    balance = "86",
    jumping = "92",
    strength = "83",

    shortpassing = "88",
    longpassing = "75",
    vision = "74",
    curve = "74",

    ballcontrol = "91",
    dribbling = "89",
    reactions = "88",
    composure = "80",

    standingtackle = "42",
    slidingtackle = "39",
    interceptions = "43",
    defensiveawareness = "41",
    aggression = "68",

    finishing = "89",
    shotpower = "86",
    longshots = "75",
    volleys = "84",
    penalties = "80",
    headingaccuracy = "79",

    skillmoves = "3",
    weakfootabilitytypecode = "5",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "42991681",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Sophia",
    surname = "Wilson",
    playerjerseyname = "Wilson"
})

Log("Created FICTIVE Gold Rare Sophia Wilson (18 yo)")
