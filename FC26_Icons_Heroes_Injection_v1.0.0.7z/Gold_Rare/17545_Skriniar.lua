-- Gold Rare Milan Škriniar (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 232363
-- Card UID : 17545
-- Fictive Player ID : 46600
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46600
local real_playerid = 232363
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "43",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "188",
    weight = "80",
    preferredfoot = "1",

    overallrating = "81",
    potential = "81",
    internationalrep = "3",

    acceleration = "53",
    sprintspeed = "61",
    stamina = "68",
    agility = "47",
    balance = "56",
    jumping = "84",
    strength = "88",

    shortpassing = "73",
    longpassing = "71",
    vision = "57",
    curve = "47",

    ballcontrol = "70",
    dribbling = "64",
    reactions = "80",
    composure = "78",

    standingtackle = "84",
    slidingtackle = "79",
    interceptions = "82",
    defensiveawareness = "84",
    aggression = "81",

    finishing = "52",
    shotpower = "68",
    longshots = "71",
    volleys = "40",
    penalties = "56",
    headingaccuracy = "82",

    skillmoves = "1",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268451840",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Milan",
    surname = "Škriniar",
    playerjerseyname = "Škriniar"
})

Log("Created FICTIVE Gold Rare Milan Škriniar (18 yo)")
