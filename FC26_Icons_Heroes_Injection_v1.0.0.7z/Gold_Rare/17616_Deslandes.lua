-- Gold Rare Océane Deslandes (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 264866
-- Card UID : 17616
-- Fictive Player ID : 46640
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46640
local real_playerid = 264866
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "169",
    weight = "61",
    preferredfoot = "2",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "63",
    sprintspeed = "74",
    stamina = "84",
    agility = "46",
    balance = "65",
    jumping = "83",
    strength = "78",

    shortpassing = "84",
    longpassing = "81",
    vision = "69",
    curve = "82",

    ballcontrol = "83",
    dribbling = "73",
    reactions = "79",
    composure = "81",

    standingtackle = "83",
    slidingtackle = "75",
    interceptions = "80",
    defensiveawareness = "80",
    aggression = "76",

    finishing = "43",
    shotpower = "71",
    longshots = "81",
    volleys = "39",
    penalties = "60",
    headingaccuracy = "80",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "132872",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Océane",
    surname = "Deslandes",
    playerjerseyname = "Deslandes"
})

Log("Created FICTIVE Gold Rare Océane Deslandes (18 yo)")
