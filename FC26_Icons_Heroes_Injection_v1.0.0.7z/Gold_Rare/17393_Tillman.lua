-- Gold Rare Malik Tillman (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 256853
-- Card UID : 17393
-- Fictive Player ID : 46491
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46491
local real_playerid = 256853
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "95",

    preferredposition1 = "18",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "71",
    preferredfoot = "1",

    overallrating = "82",
    potential = "82",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "84",
    stamina = "76",
    agility = "83",
    balance = "82",
    jumping = "88",
    strength = "82",

    shortpassing = "80",
    longpassing = "75",
    vision = "79",
    curve = "82",

    ballcontrol = "84",
    dribbling = "83",
    reactions = "81",
    composure = "78",

    standingtackle = "67",
    slidingtackle = "59",
    interceptions = "66",
    defensiveawareness = "60",
    aggression = "62",

    finishing = "75",
    shotpower = "77",
    longshots = "75",
    volleys = "60",
    penalties = "60",
    headingaccuracy = "73",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "5251332",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Malik",
    surname = "Tillman",
    playerjerseyname = "Tillman"
})

Log("Created FICTIVE Gold Rare Malik Tillman (18 yo)")
