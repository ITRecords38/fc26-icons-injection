-- Gold Rare Scott McTominay (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 237238
-- Card UID : 206
-- Fictive Player ID : 46074
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46074
local real_playerid = 237238
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "42",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "193",
    weight = "88",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "70",
    sprintspeed = "80",
    stamina = "92",
    agility = "55",
    balance = "48",
    jumping = "86",
    strength = "82",

    shortpassing = "84",
    longpassing = "81",
    vision = "79",
    curve = "69",

    ballcontrol = "85",
    dribbling = "84",
    reactions = "86",
    composure = "80",

    standingtackle = "81",
    slidingtackle = "75",
    interceptions = "81",
    defensiveawareness = "78",
    aggression = "84",

    finishing = "84",
    shotpower = "86",
    longshots = "81",
    volleys = "76",
    penalties = "60",
    headingaccuracy = "81",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "538444112",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Scott",
    surname = "McTominay",
    playerjerseyname = "McTominay"
})

Log("Created FICTIVE Gold Rare Scott McTominay (18 yo)")
