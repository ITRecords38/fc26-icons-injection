-- Gold Rare Vincenzo Grifo (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 212096
-- Card UID : 17650
-- Fictive Player ID : 46657
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46657
local real_playerid = 212096
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "80",
    preferredfoot = "1",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "73",
    sprintspeed = "68",
    stamina = "81",
    agility = "78",
    balance = "76",
    jumping = "65",
    strength = "65",

    shortpassing = "81",
    longpassing = "76",
    vision = "78",
    curve = "89",

    ballcontrol = "82",
    dribbling = "81",
    reactions = "82",
    composure = "77",

    standingtackle = "41",
    slidingtackle = "30",
    interceptions = "45",
    defensiveawareness = "48",
    aggression = "52",

    finishing = "73",
    shotpower = "85",
    longshots = "76",
    volleys = "73",
    penalties = "74",
    headingaccuracy = "47",

    skillmoves = "3",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "4481",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Vincenzo",
    surname = "Grifo",
    playerjerseyname = "Grifo"
})

Log("Created FICTIVE Gold Rare Vincenzo Grifo (18 yo)")
