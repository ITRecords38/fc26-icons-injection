-- Gold Rare Andrey N. dos Santos (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 273018
-- Card UID : 332
-- Fictive Player ID : 46151
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46151
local real_playerid = 273018
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "75",
    preferredfoot = "1",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "77",
    sprintspeed = "71",
    stamina = "91",
    agility = "77",
    balance = "69",
    jumping = "88",
    strength = "75",

    shortpassing = "82",
    longpassing = "79",
    vision = "79",
    curve = "68",

    ballcontrol = "80",
    dribbling = "77",
    reactions = "79",
    composure = "80",

    standingtackle = "81",
    slidingtackle = "81",
    interceptions = "78",
    defensiveawareness = "69",
    aggression = "78",

    finishing = "69",
    shotpower = "73",
    longshots = "79",
    volleys = "53",
    penalties = "54",
    headingaccuracy = "81",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "788496",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Andrey N. dos",
    surname = "Santos",
    playerjerseyname = "Santos"
})

Log("Created FICTIVE Gold Rare Andrey N. dos Santos (18 yo)")
