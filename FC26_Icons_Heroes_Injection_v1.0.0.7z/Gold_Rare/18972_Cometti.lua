-- Gold Rare Aldana Cometti (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 246364
-- Card UID : 18972
-- Fictive Player ID : 46887
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46887
local real_playerid = 246364
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "168",
    weight = "56",
    preferredfoot = "1",

    overallrating = "79",
    potential = "79",
    internationalrep = "3",

    acceleration = "63",
    sprintspeed = "62",
    stamina = "77",
    agility = "65",
    balance = "76",
    jumping = "86",
    strength = "82",

    shortpassing = "79",
    longpassing = "78",
    vision = "35",
    curve = "32",

    ballcontrol = "70",
    dribbling = "55",
    reactions = "76",
    composure = "65",

    standingtackle = "80",
    slidingtackle = "77",
    interceptions = "80",
    defensiveawareness = "81",
    aggression = "76",

    finishing = "25",
    shotpower = "42",
    longshots = "78",
    volleys = "23",
    penalties = "50",
    headingaccuracy = "81",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "475152",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Aldana",
    surname = "Cometti",
    playerjerseyname = "Cometti"
})

Log("Created FICTIVE Gold Rare Aldana Cometti (18 yo)")
