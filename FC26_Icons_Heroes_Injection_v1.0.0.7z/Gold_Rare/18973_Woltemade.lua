-- Gold Rare Nick Woltemade (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 254022
-- Card UID : 18973
-- Fictive Player ID : 46888
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46888
local real_playerid = 254022
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "199",
    weight = "90",
    preferredfoot = "1",

    overallrating = "79",
    potential = "79",
    internationalrep = "3",

    acceleration = "64",
    sprintspeed = "69",
    stamina = "71",
    agility = "69",
    balance = "57",
    jumping = "84",
    strength = "81",

    shortpassing = "77",
    longpassing = "63",
    vision = "74",
    curve = "51",

    ballcontrol = "80",
    dribbling = "83",
    reactions = "79",
    composure = "77",

    standingtackle = "44",
    slidingtackle = "30",
    interceptions = "35",
    defensiveawareness = "32",
    aggression = "60",

    finishing = "82",
    shotpower = "81",
    longshots = "63",
    volleys = "73",
    penalties = "70",
    headingaccuracy = "77",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1048704",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Nick",
    surname = "Woltemade",
    playerjerseyname = "Woltemade"
})

Log("Created FICTIVE Gold Rare Nick Woltemade (18 yo)")
