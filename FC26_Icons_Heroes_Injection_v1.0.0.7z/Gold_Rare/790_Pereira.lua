-- Gold Rare Danilo Luís Hélio Pereira (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 200888
-- Card UID : 790
-- Fictive Player ID : 46262
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46262
local real_playerid = 200888
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "38",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "188",
    weight = "83",
    preferredfoot = "1",

    overallrating = "81",
    potential = "81",
    internationalrep = "3",

    acceleration = "39",
    sprintspeed = "54",
    stamina = "78",
    agility = "51",
    balance = "48",
    jumping = "80",
    strength = "88",

    shortpassing = "76",
    longpassing = "70",
    vision = "70",
    curve = "54",

    ballcontrol = "76",
    dribbling = "72",
    reactions = "82",
    composure = "78",

    standingtackle = "81",
    slidingtackle = "80",
    interceptions = "84",
    defensiveawareness = "82",
    aggression = "81",

    finishing = "58",
    shotpower = "75",
    longshots = "70",
    volleys = "55",
    penalties = "58",
    headingaccuracy = "84",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268502544",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Danilo Luís Hélio",
    surname = "Pereira",
    playerjerseyname = "Pereira"
})

Log("Created FICTIVE Gold Rare Danilo Luís Hélio Pereira (18 yo)")
