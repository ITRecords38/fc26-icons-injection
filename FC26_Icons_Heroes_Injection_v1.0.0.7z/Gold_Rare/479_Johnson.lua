-- Gold Rare Brennan Johnson (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 251421
-- Card UID : 479
-- Fictive Player ID : 46194
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46194
local real_playerid = 251421
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "50",

    preferredposition1 = "23",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "186",
    weight = "73",
    preferredfoot = "1",

    overallrating = "79",
    potential = "79",
    internationalrep = "3",

    acceleration = "87",
    sprintspeed = "85",
    stamina = "78",
    agility = "81",
    balance = "66",
    jumping = "70",
    strength = "52",

    shortpassing = "74",
    longpassing = "63",
    vision = "78",
    curve = "64",

    ballcontrol = "78",
    dribbling = "78",
    reactions = "78",
    composure = "79",

    standingtackle = "45",
    slidingtackle = "53",
    interceptions = "23",
    defensiveawareness = "45",
    aggression = "48",

    finishing = "82",
    shotpower = "74",
    longshots = "63",
    volleys = "73",
    penalties = "67",
    headingaccuracy = "58",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "35651584",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Brennan",
    surname = "Johnson",
    playerjerseyname = "Johnson"
})

Log("Created FICTIVE Gold Rare Brennan Johnson (18 yo)")
