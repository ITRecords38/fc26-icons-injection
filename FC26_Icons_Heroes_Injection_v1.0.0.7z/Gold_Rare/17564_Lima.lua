-- Gold Rare Lucas Tolentino Coelho de Lima (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 233927
-- Card UID : 17564
-- Fictive Player ID : 46616
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46616
local real_playerid = 233927
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "54",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "72",
    preferredfoot = "2",

    overallrating = "80",
    potential = "80",
    internationalrep = "3",

    acceleration = "69",
    sprintspeed = "67",
    stamina = "76",
    agility = "75",
    balance = "76",
    jumping = "75",
    strength = "73",

    shortpassing = "80",
    longpassing = "80",
    vision = "80",
    curve = "77",

    ballcontrol = "85",
    dribbling = "86",
    reactions = "79",
    composure = "86",

    standingtackle = "73",
    slidingtackle = "63",
    interceptions = "71",
    defensiveawareness = "67",
    aggression = "78",

    finishing = "78",
    shotpower = "77",
    longshots = "80",
    volleys = "74",
    penalties = "82",
    headingaccuracy = "68",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "5768192",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Lucas Tolentino Coelho de",
    surname = "Lima",
    playerjerseyname = "Lima"
})

Log("Created FICTIVE Gold Rare Lucas Tolentino Coelho de Lima (18 yo)")
