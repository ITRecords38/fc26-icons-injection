-- Gold Rare Manuel Neuer (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 167495
-- Card UID : 1029
-- Fictive Player ID : 46325
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46325
local real_playerid = 167495
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "193",
    weight = "93",
    preferredfoot = "1",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "29",
    sprintspeed = "35",
    stamina = "43",
    agility = "51",
    balance = "35",
    jumping = "71",
    strength = "80",

    shortpassing = "60",
    longpassing = "67",
    vision = "68",
    curve = "14",

    ballcontrol = "44",
    dribbling = "30",
    reactions = "83",
    composure = "67",

    standingtackle = "10",
    slidingtackle = "11",
    interceptions = "30",
    defensiveawareness = "17",
    aggression = "29",

    finishing = "13",
    shotpower = "68",
    longshots = "67",
    volleys = "11",
    penalties = "49",
    headingaccuracy = "25",

    skillmoves = "0",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1024",
    trait2 = "1",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Manuel",
    surname = "Neuer",
    playerjerseyname = "Neuer"
})

Log("Created FICTIVE Gold Rare Manuel Neuer (18 yo)")
