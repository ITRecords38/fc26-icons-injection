-- Gold Rare Hannah Hampton (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 263009
-- Card UID : 583
-- Fictive Player ID : 46217
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46217
local real_playerid = 263009
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "64",
    preferredfoot = "1",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "61",
    sprintspeed = "58",
    stamina = "25",
    agility = "35",
    balance = "47",
    jumping = "64",
    strength = "50",

    shortpassing = "31",
    longpassing = "35",
    vision = "45",
    curve = "27",

    ballcontrol = "30",
    dribbling = "19",
    reactions = "83",
    composure = "38",

    standingtackle = "13",
    slidingtackle = "14",
    interceptions = "11",
    defensiveawareness = "12",
    aggression = "25",

    finishing = "8",
    shotpower = "62",
    longshots = "35",
    volleys = "11",
    penalties = "24",
    headingaccuracy = "9",

    skillmoves = "0",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1024",
    trait2 = "4",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Hannah",
    surname = "Hampton",
    playerjerseyname = "Hampton"
})

Log("Created FICTIVE Gold Rare Hannah Hampton (18 yo)")
