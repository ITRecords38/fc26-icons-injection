-- Gold Rare Leon Goretzka (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 209658
-- Card UID : 17382
-- Fictive Player ID : 46480
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46480
local real_playerid = 209658
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "189",
    weight = "82",
    preferredfoot = "1",

    overallrating = "82",
    potential = "82",
    internationalrep = "3",

    acceleration = "72",
    sprintspeed = "81",
    stamina = "69",
    agility = "74",
    balance = "71",
    jumping = "84",
    strength = "87",

    shortpassing = "85",
    longpassing = "84",
    vision = "79",
    curve = "76",

    ballcontrol = "82",
    dribbling = "80",
    reactions = "85",
    composure = "82",

    standingtackle = "83",
    slidingtackle = "75",
    interceptions = "85",
    defensiveawareness = "75",
    aggression = "83",

    finishing = "76",
    shotpower = "83",
    longshots = "84",
    volleys = "74",
    penalties = "60",
    headingaccuracy = "84",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268960020",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Leon",
    surname = "Goretzka",
    playerjerseyname = "Goretzka"
})

Log("Created FICTIVE Gold Rare Leon Goretzka (18 yo)")
