-- Gold Rare Lautaro Martínez (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 231478
-- Card UID : 60
-- Fictive Player ID : 46015
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46015
local real_playerid = 231478
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "52",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "174",
    weight = "72",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "80",
    stamina = "86",
    agility = "88",
    balance = "87",
    jumping = "91",
    strength = "80",

    shortpassing = "78",
    longpassing = "72",
    vision = "79",
    curve = "84",

    ballcontrol = "84",
    dribbling = "81",
    reactions = "92",
    composure = "88",

    standingtackle = "50",
    slidingtackle = "45",
    interceptions = "48",
    defensiveawareness = "45",
    aggression = "87",

    finishing = "93",
    shotpower = "87",
    longshots = "72",
    volleys = "92",
    penalties = "74",
    headingaccuracy = "86",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "605028628",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Lautaro",
    surname = "Martínez",
    playerjerseyname = "Martínez"
})

Log("Created FICTIVE Gold Rare Lautaro Martínez (18 yo)")
