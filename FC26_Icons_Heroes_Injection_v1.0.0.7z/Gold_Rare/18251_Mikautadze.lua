-- Gold Rare Georges Mikautadze (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 254551
-- Card UID : 18251
-- Fictive Player ID : 46803
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46803
local real_playerid = 254551
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "20",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "176",
    weight = "71",
    preferredfoot = "1",

    overallrating = "77",
    potential = "77",
    internationalrep = "3",

    acceleration = "81",
    sprintspeed = "81",
    stamina = "76",
    agility = "85",
    balance = "81",
    jumping = "77",
    strength = "67",

    shortpassing = "76",
    longpassing = "68",
    vision = "71",
    curve = "71",

    ballcontrol = "79",
    dribbling = "80",
    reactions = "75",
    composure = "78",

    standingtackle = "40",
    slidingtackle = "40",
    interceptions = "28",
    defensiveawareness = "39",
    aggression = "67",

    finishing = "80",
    shotpower = "81",
    longshots = "68",
    volleys = "80",
    penalties = "82",
    headingaccuracy = "62",

    skillmoves = "3",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "5243009",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Georges",
    surname = "Mikautadze",
    playerjerseyname = "Mikautadze"
})

Log("Created FICTIVE Gold Rare Georges Mikautadze (18 yo)")
