-- Gold Rare Jaelin Howell (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 266401
-- Card UID : 18259
-- Fictive Player ID : 46806
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46806
local real_playerid = 266401
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "95",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "172",
    weight = "64",
    preferredfoot = "1",

    overallrating = "77",
    potential = "77",
    internationalrep = "3",

    acceleration = "63",
    sprintspeed = "66",
    stamina = "84",
    agility = "73",
    balance = "77",
    jumping = "71",
    strength = "72",

    shortpassing = "80",
    longpassing = "74",
    vision = "74",
    curve = "53",

    ballcontrol = "83",
    dribbling = "76",
    reactions = "79",
    composure = "72",

    standingtackle = "77",
    slidingtackle = "63",
    interceptions = "80",
    defensiveawareness = "76",
    aggression = "79",

    finishing = "63",
    shotpower = "62",
    longshots = "74",
    volleys = "44",
    penalties = "54",
    headingaccuracy = "60",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "17432576",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Jaelin",
    surname = "Howell",
    playerjerseyname = "Howell"
})

Log("Created FICTIVE Gold Rare Jaelin Howell (18 yo)")
