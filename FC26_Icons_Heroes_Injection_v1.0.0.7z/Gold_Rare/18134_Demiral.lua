-- Gold Rare Merih Demiral (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 238160
-- Card UID : 18134
-- Fictive Player ID : 46784
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46784
local real_playerid = 238160
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "48",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "190",
    weight = "86",
    preferredfoot = "1",

    overallrating = "78",
    potential = "78",
    internationalrep = "3",

    acceleration = "66",
    sprintspeed = "78",
    stamina = "69",
    agility = "63",
    balance = "63",
    jumping = "86",
    strength = "85",

    shortpassing = "64",
    longpassing = "61",
    vision = "38",
    curve = "48",

    ballcontrol = "63",
    dribbling = "57",
    reactions = "68",
    composure = "74",

    standingtackle = "82",
    slidingtackle = "78",
    interceptions = "77",
    defensiveawareness = "77",
    aggression = "83",

    finishing = "32",
    shotpower = "60",
    longshots = "61",
    volleys = "42",
    penalties = "41",
    headingaccuracy = "77",

    skillmoves = "1",
    weakfootabilitytypecode = "2",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "933888",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Merih",
    surname = "Demiral",
    playerjerseyname = "Demiral"
})

Log("Created FICTIVE Gold Rare Merih Demiral (18 yo)")
