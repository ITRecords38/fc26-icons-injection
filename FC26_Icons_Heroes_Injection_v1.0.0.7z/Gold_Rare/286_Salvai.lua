-- Gold Rare Cecilia Salvai (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 227074
-- Card UID : 286
-- Fictive Player ID : 46132
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46132
local real_playerid = 227074
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "61",
    preferredfoot = "2",

    overallrating = "81",
    potential = "81",
    internationalrep = "3",

    acceleration = "70",
    sprintspeed = "75",
    stamina = "79",
    agility = "74",
    balance = "70",
    jumping = "85",
    strength = "80",

    shortpassing = "82",
    longpassing = "84",
    vision = "54",
    curve = "46",

    ballcontrol = "76",
    dribbling = "56",
    reactions = "82",
    composure = "76",

    standingtackle = "82",
    slidingtackle = "78",
    interceptions = "79",
    defensiveawareness = "86",
    aggression = "78",

    finishing = "43",
    shotpower = "58",
    longshots = "84",
    volleys = "50",
    penalties = "52",
    headingaccuracy = "79",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "164864",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Cecilia",
    surname = "Salvai",
    playerjerseyname = "Salvai"
})

Log("Created FICTIVE Gold Rare Cecilia Salvai (18 yo)")
