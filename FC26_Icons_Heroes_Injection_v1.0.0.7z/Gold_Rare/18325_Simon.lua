-- Gold Rare Moses Simon (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 216820
-- Card UID : 18325
-- Fictive Player ID : 46813
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46813
local real_playerid = 216820
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "133",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "168",
    weight = "69",
    preferredfoot = "1",

    overallrating = "77",
    potential = "77",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "89",
    stamina = "73",
    agility = "90",
    balance = "92",
    jumping = "71",
    strength = "66",

    shortpassing = "71",
    longpassing = "62",
    vision = "70",
    curve = "73",

    ballcontrol = "78",
    dribbling = "83",
    reactions = "70",
    composure = "73",

    standingtackle = "42",
    slidingtackle = "33",
    interceptions = "34",
    defensiveawareness = "30",
    aggression = "38",

    finishing = "68",
    shotpower = "75",
    longshots = "62",
    volleys = "75",
    penalties = "75",
    headingaccuracy = "46",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "35651720",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Moses",
    surname = "Simon",
    playerjerseyname = "Simon"
})

Log("Created FICTIVE Gold Rare Moses Simon (18 yo)")
