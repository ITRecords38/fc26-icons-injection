-- UECL Primetime Cher Ndour (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 276682
-- Card UID : 20437
-- Fictive Player ID : 46006
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46006
local real_playerid = 276682
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "190",
    weight = "84",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "85",
    stamina = "82",
    agility = "80",
    balance = "77",
    jumping = "82",
    strength = "87",

    shortpassing = "89",
    longpassing = "89",
    vision = "88",
    curve = "83",

    ballcontrol = "90",
    dribbling = "88",
    reactions = "85",
    composure = "86",

    standingtackle = "76",
    slidingtackle = "73",
    interceptions = "76",
    defensiveawareness = "71",
    aggression = "72",

    finishing = "74",
    shotpower = "90",
    longshots = "89",
    volleys = "62",
    penalties = "64",
    headingaccuracy = "80",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "4270400",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Cher",
    surname = "Ndour",
    playerjerseyname = "Ndour"
})

Log("Created FICTIVE UECL Primetime Cher Ndour (18 yo)")
