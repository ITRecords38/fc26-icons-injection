-- UECL Primetime Unai López Cabrera (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 222390
-- Card UID : 20441
-- Fictive Player ID : 46008
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46008
local real_playerid = 222390
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "170",
    weight = "68",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "83",
    sprintspeed = "82",
    stamina = "89",
    agility = "90",
    balance = "93",
    jumping = "73",
    strength = "73",

    shortpassing = "90",
    longpassing = "86",
    vision = "86",
    curve = "85",

    ballcontrol = "88",
    dribbling = "86",
    reactions = "86",
    composure = "87",

    standingtackle = "81",
    slidingtackle = "73",
    interceptions = "86",
    defensiveawareness = "83",
    aggression = "89",

    finishing = "85",
    shotpower = "88",
    longshots = "86",
    volleys = "63",
    penalties = "63",
    headingaccuracy = "60",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "22088192",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Unai López",
    surname = "Cabrera",
    playerjerseyname = "Cabrera"
})

Log("Created FICTIVE UECL Primetime Unai López Cabrera (18 yo)")
