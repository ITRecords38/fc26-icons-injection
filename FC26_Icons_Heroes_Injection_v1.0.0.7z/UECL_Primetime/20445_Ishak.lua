-- UECL Primetime Mikael Ishak (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 206626
-- Card UID : 20445
-- Fictive Player ID : 46009
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46009
local real_playerid = 206626
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "46",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "184",
    weight = "81",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "86",
    stamina = "89",
    agility = "81",
    balance = "86",
    jumping = "93",
    strength = "95",

    shortpassing = "84",
    longpassing = "77",
    vision = "81",
    curve = "66",

    ballcontrol = "90",
    dribbling = "83",
    reactions = "90",
    composure = "94",

    standingtackle = "68",
    slidingtackle = "50",
    interceptions = "59",
    defensiveawareness = "65",
    aggression = "81",

    finishing = "89",
    shotpower = "92",
    longshots = "77",
    volleys = "85",
    penalties = "87",
    headingaccuracy = "88",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "537920085",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Mikael",
    surname = "Ishak",
    playerjerseyname = "Ishak"
})

Log("Created FICTIVE UECL Primetime Mikael Ishak (18 yo)")
