-- UECL Primetime Yeremy Jesús Pino Santos (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 259377
-- Card UID : 20465
-- Fictive Player ID : 46010
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46010
local real_playerid = 259377
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "45",

    preferredposition1 = "12",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "172",
    weight = "65",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "92",
    sprintspeed = "91",
    stamina = "88",
    agility = "86",
    balance = "86",
    jumping = "70",
    strength = "50",

    shortpassing = "88",
    longpassing = "85",
    vision = "85",
    curve = "84",

    ballcontrol = "87",
    dribbling = "87",
    reactions = "84",
    composure = "82",

    standingtackle = "57",
    slidingtackle = "49",
    interceptions = "34",
    defensiveawareness = "37",
    aggression = "60",

    finishing = "85",
    shotpower = "84",
    longshots = "85",
    volleys = "79",
    penalties = "66",
    headingaccuracy = "55",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "53488000",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Yeremy Jesús Pino",
    surname = "Santos",
    playerjerseyname = "Santos"
})

Log("Created FICTIVE UECL Primetime Yeremy Jesús Pino Santos (18 yo)")
