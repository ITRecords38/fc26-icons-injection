-- Cornerstones Jordan Pickford (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 204935
-- Card UID : 19988
-- Fictive Player ID : 46045
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46045
local real_playerid = 204935
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "0",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "185",
    weight = "77",
    preferredfoot = "2",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "59",
    sprintspeed = "50",
    stamina = "40",
    agility = "59",
    balance = "55",
    jumping = "75",
    strength = "72",

    shortpassing = "59",
    longpassing = "61",
    vision = "69",
    curve = "18",

    ballcontrol = "42",
    dribbling = "20",
    reactions = "82",
    composure = "65",

    standingtackle = "20",
    slidingtackle = "12",
    interceptions = "26",
    defensiveawareness = "21",
    aggression = "45",

    finishing = "19",
    shotpower = "66",
    longshots = "61",
    volleys = "20",
    penalties = "48",
    headingaccuracy = "18",

    skillmoves = "0",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1024",
    trait2 = "3",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Jordan",
    surname = "Pickford",
    playerjerseyname = "Pickford"
})

Log("Created FICTIVE Cornerstones Jordan Pickford (18 yo)")
