-- Cornerstones Corentin Tolisso (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 219683
-- Card UID : 19931
-- Fictive Player ID : 46017
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46017
local real_playerid = 219683
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "181",
    weight = "81",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "71",
    sprintspeed = "79",
    stamina = "88",
    agility = "65",
    balance = "74",
    jumping = "89",
    strength = "84",

    shortpassing = "85",
    longpassing = "86",
    vision = "83",
    curve = "75",

    ballcontrol = "85",
    dribbling = "79",
    reactions = "86",
    composure = "83",

    standingtackle = "82",
    slidingtackle = "78",
    interceptions = "82",
    defensiveawareness = "77",
    aggression = "81",

    finishing = "77",
    shotpower = "89",
    longshots = "86",
    volleys = "78",
    penalties = "70",
    headingaccuracy = "83",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "71827472",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Corentin",
    surname = "Tolisso",
    playerjerseyname = "Tolisso"
})

Log("Created FICTIVE Cornerstones Corentin Tolisso (18 yo)")
