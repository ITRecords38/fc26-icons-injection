-- Cornerstones Willi Orban (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 204638
-- Card UID : 19985
-- Fictive Player ID : 46042
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46042
local real_playerid = 204638
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "23",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "186",
    weight = "89",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "71",
    sprintspeed = "77",
    stamina = "77",
    agility = "65",
    balance = "65",
    jumping = "92",
    strength = "89",

    shortpassing = "77",
    longpassing = "70",
    vision = "46",
    curve = "29",

    ballcontrol = "60",
    dribbling = "53",
    reactions = "85",
    composure = "74",

    standingtackle = "90",
    slidingtackle = "83",
    interceptions = "86",
    defensiveawareness = "90",
    aggression = "89",

    finishing = "46",
    shotpower = "47",
    longshots = "70",
    volleys = "33",
    penalties = "43",
    headingaccuracy = "88",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268977152",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Willi",
    surname = "Orban",
    playerjerseyname = "Orban"
})

Log("Created FICTIVE Cornerstones Willi Orban (18 yo)")
