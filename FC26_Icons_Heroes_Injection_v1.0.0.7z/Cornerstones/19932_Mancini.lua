-- Cornerstones Gianluca Mancini (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 229582
-- Card UID : 19932
-- Fictive Player ID : 46018
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46018
local real_playerid = 229582
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "190",
    weight = "77",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "68",
    sprintspeed = "77",
    stamina = "86",
    agility = "63",
    balance = "63",
    jumping = "87",
    strength = "81",

    shortpassing = "74",
    longpassing = "76",
    vision = "59",
    curve = "40",

    ballcontrol = "80",
    dribbling = "65",
    reactions = "87",
    composure = "85",

    standingtackle = "86",
    slidingtackle = "80",
    interceptions = "87",
    defensiveawareness = "89",
    aggression = "89",

    finishing = "50",
    shotpower = "53",
    longshots = "76",
    volleys = "42",
    penalties = "49",
    headingaccuracy = "86",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "268632080",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Gianluca",
    surname = "Mancini",
    playerjerseyname = "Mancini"
})

Log("Created FICTIVE Cornerstones Gianluca Mancini (18 yo)")
