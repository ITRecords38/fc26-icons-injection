-- Cornerstones Trent Alexander-Arnold (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 231281
-- Card UID : 19979
-- Fictive Player ID : 46036
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46036
local real_playerid = 231281
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "69",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "80",
    sprintspeed = "86",
    stamina = "94",
    agility = "76",
    balance = "75",
    jumping = "79",
    strength = "72",

    shortpassing = "88",
    longpassing = "92",
    vision = "90",
    curve = "92",

    ballcontrol = "88",
    dribbling = "82",
    reactions = "88",
    composure = "85",

    standingtackle = "87",
    slidingtackle = "84",
    interceptions = "89",
    defensiveawareness = "83",
    aggression = "74",

    finishing = "65",
    shotpower = "86",
    longshots = "92",
    volleys = "72",
    penalties = "67",
    headingaccuracy = "73",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "67113992",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Trent",
    surname = "Alexander-Arnold",
    playerjerseyname = "Alexander-Arnold"
})

Log("Created FICTIVE Cornerstones Trent Alexander-Arnold (18 yo)")
