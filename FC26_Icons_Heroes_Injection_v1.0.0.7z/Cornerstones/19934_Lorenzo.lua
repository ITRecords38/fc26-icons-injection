-- Cornerstones Giovanni Di Lorenzo (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 217870
-- Card UID : 19934
-- Fictive Player ID : 46020
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46020
local real_playerid = 217870
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "27",

    preferredposition1 = "3",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "183",
    weight = "82",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "87",
    stamina = "92",
    agility = "80",
    balance = "77",
    jumping = "86",
    strength = "76",

    shortpassing = "79",
    longpassing = "75",
    vision = "71",
    curve = "70",

    ballcontrol = "81",
    dribbling = "80",
    reactions = "83",
    composure = "77",

    standingtackle = "84",
    slidingtackle = "81",
    interceptions = "83",
    defensiveawareness = "82",
    aggression = "81",

    finishing = "74",
    shotpower = "77",
    longshots = "75",
    volleys = "65",
    penalties = "62",
    headingaccuracy = "75",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "71304192",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Giovanni Di",
    surname = "Lorenzo",
    playerjerseyname = "Lorenzo"
})

Log("Created FICTIVE Cornerstones Giovanni Di Lorenzo (18 yo)")
