-- Cornerstones Yazmeen Ryan (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 267227
-- Card UID : 20003
-- Fictive Player ID : 46056
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46056
local real_playerid = 267227
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "95",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "168",
    weight = "66",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "89",
    stamina = "93",
    agility = "83",
    balance = "77",
    jumping = "80",
    strength = "80",

    shortpassing = "84",
    longpassing = "75",
    vision = "83",
    curve = "77",

    ballcontrol = "87",
    dribbling = "85",
    reactions = "85",
    composure = "71",

    standingtackle = "73",
    slidingtackle = "50",
    interceptions = "52",
    defensiveawareness = "46",
    aggression = "75",

    finishing = "84",
    shotpower = "84",
    longshots = "75",
    volleys = "60",
    penalties = "74",
    headingaccuracy = "59",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "37748738",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Yazmeen",
    surname = "Ryan",
    playerjerseyname = "Ryan"
})

Log("Created FICTIVE Cornerstones Yazmeen Ryan (18 yo)")
