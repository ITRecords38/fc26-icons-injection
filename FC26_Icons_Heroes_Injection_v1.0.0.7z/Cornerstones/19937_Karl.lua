-- Cornerstones Lisa Karl (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 265069
-- Card UID : 19937
-- Fictive Player ID : 46023
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46023
local real_playerid = 265069
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "168",
    weight = "60",
    preferredfoot = "1",

    overallrating = "84",
    potential = "84",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "85",
    stamina = "82",
    agility = "90",
    balance = "82",
    jumping = "94",
    strength = "80",

    shortpassing = "83",
    longpassing = "71",
    vision = "62",
    curve = "67",

    ballcontrol = "82",
    dribbling = "83",
    reactions = "80",
    composure = "72",

    standingtackle = "82",
    slidingtackle = "81",
    interceptions = "82",
    defensiveawareness = "82",
    aggression = "60",

    finishing = "79",
    shotpower = "70",
    longshots = "71",
    volleys = "56",
    penalties = "66",
    headingaccuracy = "82",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "33853440",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Lisa",
    surname = "Karl",
    playerjerseyname = "Karl"
})

Log("Created FICTIVE Cornerstones Lisa Karl (18 yo)")
