-- Cornerstones Brendan Chardonnet (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 215410
-- Card UID : 19998
-- Fictive Player ID : 46054
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46054
local real_playerid = 215410
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "18",

    preferredposition1 = "5",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "181",
    weight = "74",
    preferredfoot = "1",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "76",
    sprintspeed = "75",
    stamina = "77",
    agility = "66",
    balance = "80",
    jumping = "88",
    strength = "89",

    shortpassing = "82",
    longpassing = "75",
    vision = "48",
    curve = "48",

    ballcontrol = "78",
    dribbling = "62",
    reactions = "89",
    composure = "82",

    standingtackle = "85",
    slidingtackle = "83",
    interceptions = "86",
    defensiveawareness = "84",
    aggression = "82",

    finishing = "55",
    shotpower = "59",
    longshots = "75",
    volleys = "50",
    penalties = "79",
    headingaccuracy = "84",

    skillmoves = "1",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "622592",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Brendan",
    surname = "Chardonnet",
    playerjerseyname = "Chardonnet"
})

Log("Created FICTIVE Cornerstones Brendan Chardonnet (18 yo)")
