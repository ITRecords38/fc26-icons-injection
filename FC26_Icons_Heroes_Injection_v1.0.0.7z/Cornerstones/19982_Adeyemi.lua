-- Cornerstones Karim Adeyemi (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 251852
-- Card UID : 19982
-- Fictive Player ID : 46039
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46039
local real_playerid = 251852
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "21",

    preferredposition1 = "12",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "180",
    weight = "77",
    preferredfoot = "2",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "97",
    sprintspeed = "97",
    stamina = "83",
    agility = "90",
    balance = "85",
    jumping = "95",
    strength = "73",

    shortpassing = "80",
    longpassing = "75",
    vision = "79",
    curve = "73",

    ballcontrol = "83",
    dribbling = "88",
    reactions = "85",
    composure = "81",

    standingtackle = "40",
    slidingtackle = "55",
    interceptions = "37",
    defensiveawareness = "30",
    aggression = "65",

    finishing = "83",
    shotpower = "85",
    longshots = "75",
    volleys = "77",
    penalties = "76",
    headingaccuracy = "77",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "6291488",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Karim",
    surname = "Adeyemi",
    playerjerseyname = "Adeyemi"
})

Log("Created FICTIVE Cornerstones Karim Adeyemi (18 yo)")
