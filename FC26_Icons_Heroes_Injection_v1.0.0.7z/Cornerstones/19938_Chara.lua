-- Cornerstones Diego Chará (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 203067
-- Card UID : 19938
-- Fictive Player ID : 46024
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46024
local real_playerid = 203067
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "56",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "172",
    weight = "68",
    preferredfoot = "1",

    overallrating = "83",
    potential = "83",
    internationalrep = "3",

    acceleration = "74",
    sprintspeed = "75",
    stamina = "89",
    agility = "78",
    balance = "87",
    jumping = "73",
    strength = "76",

    shortpassing = "81",
    longpassing = "74",
    vision = "77",
    curve = "75",

    ballcontrol = "76",
    dribbling = "73",
    reactions = "77",
    composure = "81",

    standingtackle = "82",
    slidingtackle = "80",
    interceptions = "81",
    defensiveawareness = "82",
    aggression = "94",

    finishing = "61",
    shotpower = "73",
    longshots = "74",
    volleys = "66",
    penalties = "77",
    headingaccuracy = "61",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "335839232",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Diego",
    surname = "Chará",
    playerjerseyname = "Chará"
})

Log("Created FICTIVE Cornerstones Diego Chará (18 yo)")
