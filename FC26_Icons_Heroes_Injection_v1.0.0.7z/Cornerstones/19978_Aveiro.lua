-- Cornerstones Cristiano Ronaldo dos Santos Aveiro (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 20801
-- Card UID : 19978
-- Fictive Player ID : 46035
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46035
local real_playerid = 20801
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "38",

    preferredposition1 = "25",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "187",
    weight = "85",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "80",
    sprintspeed = "83",
    stamina = "81",
    agility = "78",
    balance = "74",
    jumping = "97",
    strength = "84",

    shortpassing = "79",
    longpassing = "73",
    vision = "79",
    curve = "82",

    ballcontrol = "87",
    dribbling = "80",
    reactions = "85",
    composure = "94",

    standingtackle = "35",
    slidingtackle = "26",
    interceptions = "32",
    defensiveawareness = "26",
    aggression = "65",

    finishing = "91",
    shotpower = "94",
    longshots = "73",
    volleys = "87",
    penalties = "94",
    headingaccuracy = "93",

    skillmoves = "4",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "8913076",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Cristiano Ronaldo dos Santos",
    surname = "Aveiro",
    playerjerseyname = "Aveiro"
})

Log("Created FICTIVE Cornerstones Cristiano Ronaldo dos Santos Aveiro (18 yo)")
