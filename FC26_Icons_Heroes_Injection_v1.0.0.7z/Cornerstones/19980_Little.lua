-- Cornerstones Kim Little (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 245872
-- Card UID : 19980
-- Fictive Player ID : 46037
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46037
local real_playerid = 245872
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "42",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "162",
    weight = "57",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "82",
    sprintspeed = "77",
    stamina = "91",
    agility = "91",
    balance = "90",
    jumping = "75",
    strength = "64",

    shortpassing = "92",
    longpassing = "89",
    vision = "89",
    curve = "80",

    ballcontrol = "90",
    dribbling = "89",
    reactions = "90",
    composure = "86",

    standingtackle = "90",
    slidingtackle = "80",
    interceptions = "82",
    defensiveawareness = "80",
    aggression = "74",

    finishing = "73",
    shotpower = "88",
    longshots = "89",
    volleys = "85",
    penalties = "80",
    headingaccuracy = "60",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "524548",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Kim",
    surname = "Little",
    playerjerseyname = "Little"
})

Log("Created FICTIVE Cornerstones Kim Little (18 yo)")
