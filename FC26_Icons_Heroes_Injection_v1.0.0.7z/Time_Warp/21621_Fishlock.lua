-- Time Warp Jess Fishlock (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 267201
-- Card UID : 21621
-- Fictive Player ID : 46017
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46017
local real_playerid = 267201
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "50",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "157",
    weight = "54",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "83",
    stamina = "90",
    agility = "86",
    balance = "91",
    jumping = "79",
    strength = "78",

    shortpassing = "93",
    longpassing = "87",
    vision = "95",
    curve = "85",

    ballcontrol = "93",
    dribbling = "88",
    reactions = "85",
    composure = "91",

    standingtackle = "84",
    slidingtackle = "74",
    interceptions = "82",
    defensiveawareness = "84",
    aggression = "75",

    finishing = "87",
    shotpower = "89",
    longshots = "87",
    volleys = "88",
    penalties = "80",
    headingaccuracy = "61",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "7342145",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Jess",
    surname = "Fishlock",
    playerjerseyname = "Fishlock"
})

Log("Created FICTIVE Time Warp Jess Fishlock (18 yo)")
