-- Time Warp Anthony Nwakaeme (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 241771
-- Card UID : 21626
-- Fictive Player ID : 46022
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46022
local real_playerid = 241771
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "133",

    preferredposition1 = "27",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "185",
    weight = "80",
    preferredfoot = "1",

    overallrating = "87",
    potential = "87",
    internationalrep = "3",

    acceleration = "89",
    sprintspeed = "88",
    stamina = "87",
    agility = "87",
    balance = "85",
    jumping = "87",
    strength = "96",

    shortpassing = "86",
    longpassing = "85",
    vision = "88",
    curve = "90",

    ballcontrol = "89",
    dribbling = "88",
    reactions = "85",
    composure = "90",

    standingtackle = "69",
    slidingtackle = "44",
    interceptions = "30",
    defensiveawareness = "35",
    aggression = "70",

    finishing = "83",
    shotpower = "93",
    longshots = "85",
    volleys = "80",
    penalties = "80",
    headingaccuracy = "89",

    skillmoves = "3",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1057153",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Anthony",
    surname = "Nwakaeme",
    playerjerseyname = "Nwakaeme"
})

Log("Created FICTIVE Time Warp Anthony Nwakaeme (18 yo)")
