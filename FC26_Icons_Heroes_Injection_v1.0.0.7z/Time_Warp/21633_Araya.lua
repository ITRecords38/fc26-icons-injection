-- Time Warp Karen Araya (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 245962
-- Card UID : 21633
-- Fictive Player ID : 46029
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46029
local real_playerid = 245962
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "55",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "164",
    weight = "64",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "85",
    sprintspeed = "85",
    stamina = "84",
    agility = "82",
    balance = "83",
    jumping = "82",
    strength = "81",

    shortpassing = "89",
    longpassing = "88",
    vision = "96",
    curve = "94",

    ballcontrol = "86",
    dribbling = "80",
    reactions = "86",
    composure = "89",

    standingtackle = "73",
    slidingtackle = "72",
    interceptions = "80",
    defensiveawareness = "75",
    aggression = "75",

    finishing = "84",
    shotpower = "88",
    longshots = "88",
    volleys = "70",
    penalties = "87",
    headingaccuracy = "78",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "16844545",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Karen",
    surname = "Araya",
    playerjerseyname = "Araya"
})

Log("Created FICTIVE Time Warp Karen Araya (18 yo)")
