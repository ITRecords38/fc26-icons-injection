-- Time Warp Emily van Egmond (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 227113
-- Card UID : 21620
-- Fictive Player ID : 46016
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46016
local real_playerid = 227113
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "195",

    preferredposition1 = "10",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "179",
    weight = "65",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "84",
    sprintspeed = "83",
    stamina = "94",
    agility = "80",
    balance = "80",
    jumping = "87",
    strength = "87",

    shortpassing = "90",
    longpassing = "90",
    vision = "86",
    curve = "85",

    ballcontrol = "86",
    dribbling = "80",
    reactions = "80",
    composure = "95",

    standingtackle = "88",
    slidingtackle = "84",
    interceptions = "87",
    defensiveawareness = "89",
    aggression = "84",

    finishing = "73",
    shotpower = "90",
    longshots = "90",
    volleys = "80",
    penalties = "78",
    headingaccuracy = "83",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "21169216",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Emily van",
    surname = "Egmond",
    playerjerseyname = "Egmond"
})

Log("Created FICTIVE Time Warp Emily van Egmond (18 yo)")
