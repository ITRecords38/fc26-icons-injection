-- Time Warp Patrick van Aanholt (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 186190
-- Card UID : 21638
-- Fictive Player ID : 46034
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46034
local real_playerid = 186190
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "34",

    preferredposition1 = "7",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "176",
    weight = "67",
    preferredfoot = "2",

    overallrating = "85",
    potential = "85",
    internationalrep = "3",

    acceleration = "90",
    sprintspeed = "90",
    stamina = "84",
    agility = "85",
    balance = "88",
    jumping = "90",
    strength = "82",

    shortpassing = "84",
    longpassing = "86",
    vision = "81",
    curve = "86",

    ballcontrol = "85",
    dribbling = "85",
    reactions = "80",
    composure = "82",

    standingtackle = "89",
    slidingtackle = "89",
    interceptions = "83",
    defensiveawareness = "83",
    aggression = "82",

    finishing = "70",
    shotpower = "84",
    longshots = "86",
    volleys = "70",
    penalties = "74",
    headingaccuracy = "73",

    skillmoves = "2",
    weakfootabilitytypecode = "3",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "153489408",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Patrick van",
    surname = "Aanholt",
    playerjerseyname = "Aanholt"
})

Log("Created FICTIVE Time Warp Patrick van Aanholt (18 yo)")
