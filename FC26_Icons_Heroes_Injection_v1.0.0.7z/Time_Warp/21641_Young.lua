-- Time Warp Ashley Young (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 152908
-- Card UID : 21641
-- Fictive Player ID : 46037
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46037
local real_playerid = 152908
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "14",

    preferredposition1 = "16",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "175",
    weight = "65",
    preferredfoot = "1",

    overallrating = "86",
    potential = "86",
    internationalrep = "3",

    acceleration = "93",
    sprintspeed = "93",
    stamina = "88",
    agility = "89",
    balance = "87",
    jumping = "77",
    strength = "72",

    shortpassing = "86",
    longpassing = "83",
    vision = "84",
    curve = "92",

    ballcontrol = "89",
    dribbling = "87",
    reactions = "88",
    composure = "89",

    standingtackle = "78",
    slidingtackle = "77",
    interceptions = "79",
    defensiveawareness = "77",
    aggression = "90",

    finishing = "84",
    shotpower = "87",
    longshots = "83",
    volleys = "80",
    penalties = "75",
    headingaccuracy = "77",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "1075201",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Ashley",
    surname = "Young",
    playerjerseyname = "Young"
})

Log("Created FICTIVE Time Warp Ashley Young (18 yo)")
