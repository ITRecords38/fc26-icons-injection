-- Time Warp Mario Lemina (FICTIVE ENTRY – DB SAFE)
-- Real Player ID : 212811
-- Card UID : 21619
-- Fictive Player ID : 46015
-- Career start age : 18 years

require 'imports/other/helpers'

local playerid = 46015
local real_playerid = 212811
local career_start_age = 18

assert(PlayerExists(playerid) == false, string.format(
    "Can't create. Player with ID: %d already exists", playerid
))

---------------------------------------------------
-- CREATE PLAYER
---------------------------------------------------
local player_data = {
    headassetid = tostring(real_playerid),
    headtypecode = "0",
    headvariation = "0",
    hashighqualityhead = "1",

    skintypecode = "2",
    skintonecode = "3",

    nationality = "115",

    preferredposition1 = "14",
    preferredposition2 = "-1",
    preferredposition3 = "-1",
    preferredposition4 = "-1",

    height = "184",
    weight = "85",
    preferredfoot = "1",

    overallrating = "88",
    potential = "88",
    internationalrep = "3",

    acceleration = "86",
    sprintspeed = "88",
    stamina = "86",
    agility = "89",
    balance = "87",
    jumping = "94",
    strength = "86",

    shortpassing = "90",
    longpassing = "90",
    vision = "87",
    curve = "88",

    ballcontrol = "88",
    dribbling = "88",
    reactions = "90",
    composure = "92",

    standingtackle = "84",
    slidingtackle = "82",
    interceptions = "86",
    defensiveawareness = "84",
    aggression = "85",

    finishing = "67",
    shotpower = "90",
    longshots = "90",
    volleys = "75",
    penalties = "77",
    headingaccuracy = "87",

    skillmoves = "2",
    weakfootabilitytypecode = "4",

    attackingworkrate = "2",
    defensiveworkrate = "2",

    trait1 = "68183040",
    trait2 = "0",

    teamid = "111592",
    contractvaliduntil = "2029",

    iscustomized = "1",
    usercaneditname = "0"
}

local created_playerid = CreatePlayer(playerid, player_data)

---------------------------------------------------
-- FIX BIRTHDATE
---------------------------------------------------
local current_date = GetCurrentDate()
local players_table = LE.db:GetTable("players")
local record = players_table:GetFirstRecord()
local normalized_birthdate = DATE:new()

while record > 0 do
    if players_table:GetRecordFieldValue(record, "playerid") == created_playerid then
        local birthdate = players_table:GetRecordFieldValue(record, "birthdate")
        normalized_birthdate:FromGregorianDays(birthdate)
        normalized_birthdate.year = current_date.year - career_start_age
        players_table:SetRecordFieldValue(record, "birthdate", normalized_birthdate:ToGregorianDays())
        break
    end
    record = players_table:GetNextValidRecord()
end

---------------------------------------------------
-- NAME TABLE
---------------------------------------------------
InsertDBTableRow("editedplayernames", {
    playerid = tostring(created_playerid),
    firstname = "Mario",
    surname = "Lemina",
    playerjerseyname = "Lemina"
})

Log("Created FICTIVE Time Warp Mario Lemina (18 yo)")
